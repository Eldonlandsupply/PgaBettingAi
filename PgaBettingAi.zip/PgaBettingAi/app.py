import os
import logging
from datetime import datetime
from flask import Flask, jsonify, request, render_template, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix
from apscheduler.schedulers.background import BackgroundScheduler
import atexit

# Configure logging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Create the Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///pga_betting.db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize the app with the extension
db.init_app(app)

# Import models for use in routes
from models import User, Tournament, Player, Prediction, Bet, ModelPerformance
from services.live_tournament_service import LiveTournamentService, refresh_live_tournament_data

with app.app_context():
    # Ensure tables are created
    db.create_all()

# Service imports
from services.pga_api import get_tournament_data, get_player_stats
from services.ml_models import predict_scores, train_model
from services.odds_analysis import analyze_odds
from services.weather_service import get_weather_impact
from services.chatgpt_service import analyze_with_chatgpt
from services.user_service import create_user, authenticate_user, get_user_profile
from services.analytics_service import generate_report
from services.telegram_bot_service import start_telegram_bot, send_daily_picks
from services.data_refresh_service import full_data_refresh, refresh_tournament_data, refresh_player_rankings

# Initialize scheduler
scheduler = BackgroundScheduler()
scheduler.start()
atexit.register(lambda: scheduler.shutdown())

# REST API endpoints
@app.route('/api/pga')
def api_pga():
    try:
        data = get_tournament_data()
        return jsonify(data)
    except Exception as e:
        logging.error(f"Error in /api/pga: {e}")
        return jsonify({"error": "Failed to fetch PGA data"}), 500

@app.route('/api/predict', methods=['POST'])
def api_predict():
    try:
        data = request.json
        predictions = predict_scores(data)
        return jsonify(predictions)
    except Exception as e:
        logging.error(f"Error in /api/predict: {e}")
        return jsonify({"error": "Failed to generate predictions"}), 500

@app.route('/api/odds', methods=['POST'])
def api_odds():
    try:
        bets = request.json
        analysis = analyze_odds(bets)
        return jsonify(analysis)
    except Exception as e:
        logging.error(f"Error in /api/odds: {e}")
        return jsonify({"error": "Failed to analyze odds"}), 500

@app.route('/api/weather')
def api_weather():
    try:
        weather_data = get_weather_impact()
        return jsonify(weather_data)
    except Exception as e:
        logging.error(f"Error in /api/weather: {e}")
        return jsonify({"error": "Failed to fetch weather data"}), 500

@app.route('/api/chatgpt', methods=['POST'])
def api_chatgpt():
    try:
        prompt = request.json.get('prompt')
        if not prompt:
            return jsonify({"error": "Prompt is required"}), 400
        analysis = analyze_with_chatgpt(prompt)
        return jsonify(analysis)
    except Exception as e:
        logging.error(f"Error in /api/chatgpt: {e}")
        return jsonify({"error": "Failed to analyze with ChatGPT"}), 500

@app.route('/api/users/signup', methods=['POST'])
def api_signup():
    try:
        result = create_user(request.json)
        return jsonify(result)
    except Exception as e:
        logging.error(f"Error in /api/users/signup: {e}")
        return jsonify({"error": "Failed to create user"}), 500

@app.route('/api/users/login', methods=['POST'])
def api_login():
    try:
        result = authenticate_user(request.json)
        if result.get('success'):
            session['user_id'] = result['user_id']
        return jsonify(result)
    except Exception as e:
        logging.error(f"Error in /api/users/login: {e}")
        return jsonify({"error": "Failed to authenticate user"}), 500

@app.route('/api/users/profile')
def api_profile():
    try:
        user_id = request.args.get('id') or session.get('user_id')
        if not user_id:
            return jsonify({"error": "User ID required"}), 400
        profile = get_user_profile(user_id)
        return jsonify(profile)
    except Exception as e:
        logging.error(f"Error in /api/users/profile: {e}")
        return jsonify({"error": "Failed to fetch user profile"}), 500

@app.route('/api/analytics')
def api_analytics():
    try:
        report = generate_report()
        return jsonify(report)
    except Exception as e:
        logging.error(f"Error in /api/analytics: {e}")
        return jsonify({"error": "Failed to generate analytics report"}), 500

@app.route('/api/refresh-data', methods=['POST'])
def api_refresh_data():
    """Manual data refresh endpoint"""
    try:
        refresh_type = request.json.get('type', 'full') if request.json else 'full'
        
        if refresh_type == 'tournaments':
            result = refresh_tournament_data()
        elif refresh_type == 'players':
            refresh_player_rankings()
            result = {'success': True, 'message': 'Player rankings refreshed'}
        else:
            result = full_data_refresh()
        
        return jsonify(result)
        
    except Exception as e:
        logging.error(f"Error in manual data refresh: {e}")
        return jsonify({"error": "Failed to refresh data", "details": str(e)}), 500

@app.route('/api/tournament-status')
def api_tournament_status():
    """Get current tournament status and data freshness"""
    try:
        tournaments = Tournament.query.filter_by(status='upcoming').limit(5).all()
        tournament_data = []
        
        for tournament in tournaments:
            tournament_data.append({
                'id': tournament.id,
                'name': tournament.name,
                'course': tournament.course,
                'start_date': tournament.start_date.isoformat() if tournament.start_date else None,
                'end_date': tournament.end_date.isoformat() if tournament.end_date else None,
                'purse': tournament.purse,
                'status': tournament.status
            })
        
        # Get prediction count for each tournament
        for tournament in tournament_data:
            pred_count = Prediction.query.filter_by(tournament_id=tournament['id']).count()
            tournament['prediction_count'] = pred_count
        
        return jsonify({
            'success': True,
            'tournaments': tournament_data,
            'total_tournaments': len(tournament_data),
            'last_refresh': datetime.now().isoformat()
        })
        
    except Exception as e:
        logging.error(f"Error getting tournament status: {e}")
        return jsonify({"error": "Failed to get tournament status"}), 500

# Web interface routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        flash('Please log in to access the dashboard.', 'warning')
        return redirect(url_for('home'))
    
    try:
        # Get current tournament data
        tournament_data = get_tournament_data()
        user_profile = get_user_profile(session['user_id'])
        analytics = generate_report()
        
        return render_template('dashboard.html', 
                             tournament=tournament_data,
                             user=user_profile,
                             analytics=analytics)
    except Exception as e:
        logging.error(f"Error loading dashboard: {e}")
        flash('Error loading dashboard data.', 'error')
        return redirect(url_for('home'))

@app.route('/predictions')
def predictions():
    try:
        # Get tournament data and weather
        tournament_data = get_tournament_data()
        weather_data = get_weather_impact()
        
        # Get tournament ID from URL parameter or default to current tournament
        tournament_id = request.args.get('tournament_id', type=int)
        
        if tournament_id:
            # Get specific tournament
            selected_tournament = db.session.query(Tournament).filter(
                Tournament.id == tournament_id
            ).first()
        else:
            # Get current tournament (John Deere Classic 2025) as default
            selected_tournament = db.session.query(Tournament).filter(
                Tournament.name == 'John Deere Classic'
            ).order_by(Tournament.start_date.desc()).first()
        
        # Get predictions from database for selected tournament, filtered by actual tournament field
        if selected_tournament:
            from models import TournamentPlayer
            
            # Get players actually committed to this tournament
            tournament_player_ids = db.session.query(TournamentPlayer.player_id).filter(
                TournamentPlayer.tournament_id == selected_tournament.id,
                TournamentPlayer.status == 'committed'
            ).subquery()
            
            predictions_query = db.session.query(Prediction, Player, Tournament).join(
                Player, Prediction.player_id == Player.id
            ).join(
                Tournament, Prediction.tournament_id == Tournament.id
            ).filter(
                Tournament.id == selected_tournament.id,
                Player.id.in_(tournament_player_ids)
            ).order_by(Prediction.confidence_score.desc()).limit(10).all()
        else:
            # Fallback to any recent predictions
            predictions_query = db.session.query(Prediction, Player, Tournament).join(
                Player, Prediction.player_id == Player.id
            ).join(
                Tournament, Prediction.tournament_id == Tournament.id
            ).order_by(Prediction.created_at.desc()).limit(10).all()
        
        # Get all tournaments for dropdown
        all_tournaments = db.session.query(Tournament).order_by(Tournament.start_date.desc()).all()
        tournament_options = []
        for t in all_tournaments:
            tournament_options.append({
                'id': t.id,
                'name': t.name,
                'course': t.course,
                'start_date': t.start_date.strftime('%B %d-%d, %Y') if t.start_date else 'TBD',
                'selected': t.id == (selected_tournament.id if selected_tournament else None)
            })
        
        # Format predictions for template
        formatted_predictions = []
        for pred, player, tournament in predictions_query:
            formatted_predictions.append({
                'player_name': player.name,
                'tournament_name': tournament.name,
                'predicted_score': pred.predicted_score,
                'win_probability': pred.win_probability * 100,  # Convert to percentage
                'confidence_score': pred.confidence_score * 100,  # Convert to percentage
                'prediction_type': pred.prediction_type,
                'world_ranking': player.world_ranking,
                'recent_form': player.recent_form
            })
        
        # Create tournament data for display from selected tournament
        if selected_tournament:
            selected_tournament_data = {
                'success': True,
                'tournaments': [{
                    'name': selected_tournament.name,
                    'course': selected_tournament.course,
                    'start_date': selected_tournament.start_date.strftime('%B %d-%d, %Y') if selected_tournament.start_date else 'TBD',
                    'end_date': selected_tournament.end_date,
                    'purse': selected_tournament.purse,
                    'status': selected_tournament.status,
                    'weather_conditions': selected_tournament.weather_conditions
                }],
                'message': f'Tournament data for {selected_tournament.name}',
                'last_updated': datetime.now().isoformat()
            }
        else:
            selected_tournament_data = tournament_data

        return render_template('predictions.html', 
                             tournament=selected_tournament_data,
                             weather=weather_data,
                             predictions=formatted_predictions,
                             tournament_options=tournament_options,
                             selected_tournament_id=selected_tournament.id if selected_tournament else None)
    except Exception as e:
        logging.error(f"Error loading predictions: {e}")
        flash('Error loading predictions.', 'error')
        return redirect(url_for('home'))

@app.route('/profile')
def profile():
    if 'user_id' not in session:
        flash('Please log in to view your profile.', 'warning')
        return redirect(url_for('home'))
    
    try:
        user_profile = get_user_profile(session['user_id'])
        return render_template('profile.html', user=user_profile)
    except Exception as e:
        logging.error(f"Error loading profile: {e}")
        flash('Error loading profile.', 'error')
        return redirect(url_for('home'))

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('home'))

@app.route('/admin')
def admin():
    """Admin panel for data management"""
    return render_template('admin.html')

@app.route('/ai_assistant')
def ai_assistant():
    """AI-powered golf betting assistant interface"""
    return render_template('ai_assistant.html')

@app.route('/api/refresh_live_data', methods=['POST'])
def api_refresh_live_data():
    """Refresh live tournament field data from DataGolf/ESPN APIs"""
    try:
        success = refresh_live_tournament_data()
        
        if success:
            return jsonify({
                'success': True,
                'message': 'Live tournament data refreshed successfully',
                'refreshed_at': datetime.now().isoformat()
            })
        else:
            return jsonify({
                'success': False,
                'message': 'Failed to refresh live tournament data'
            }), 500
            
    except Exception as e:
        logging.error(f"Error refreshing live data: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/live_field/<tournament_name>', methods=['GET'])
def api_live_field(tournament_name):
    """Get current live tournament field data"""
    try:
        live_service = LiveTournamentService()
        
        if tournament_name.lower() == 'john-deere-classic':
            field_data = live_service.get_john_deere_classic_field()
        else:
            tournaments = live_service.get_current_week_tournaments()
            field_data = {'success': False, 'error': 'Tournament not found'}
            
            if tournaments['success']:
                for tournament in tournaments['tournaments']:
                    if tournament_name.lower() in tournament.get('event_name', '').lower():
                        field_data = live_service.get_tournament_field(tournament.get('event_id', ''))
                        break
        
        return jsonify(field_data)
        
    except Exception as e:
        logging.error(f"Error getting live field data: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/ai_assistant', methods=['POST'])
def api_ai_assistant():
    """AI-powered golf betting assistant that leverages all available data"""
    try:
        data = request.get_json()
        question = data.get('question', '')
        chat_history = data.get('chat_history', [])
        
        if not question:
            return jsonify({'success': False, 'error': 'No question provided'}), 400
        
        # Gather comprehensive context data
        context_data = gather_ai_context()
        
        # Generate AI response using ChatGPT with enhanced context
        response = generate_ai_response(question, context_data, chat_history)
        
        return jsonify({
            'success': True,
            'response': response,
            'context_used': context_data.get('summary', 'Full tournament and player data')
        })
        
    except Exception as e:
        logging.error(f"Error in AI assistant: {e}")
        return jsonify({
            'success': False,
            'error': 'AI assistant temporarily unavailable'
        }), 500

def gather_ai_context():
    """Gather comprehensive context data for AI assistant"""
    try:
        context = {
            'current_date': datetime.now().strftime('%Y-%m-%d'),
            'tournaments': [],
            'players': [],
            'predictions': [],
            'weather': [],
            'recent_bets': []
        }
        
        # Get upcoming tournaments
        upcoming_tournaments = Tournament.query.filter(
            Tournament.start_date >= datetime.now().date()
        ).order_by(Tournament.start_date.asc()).limit(5).all()
        
        for tournament in upcoming_tournaments:
            context['tournaments'].append({
                'name': tournament.name,
                'course': tournament.course,
                'start_date': tournament.start_date.strftime('%Y-%m-%d') if tournament.start_date else None,
                'end_date': tournament.end_date.strftime('%Y-%m-%d') if tournament.end_date else None,
                'purse': tournament.purse,
                'status': tournament.status
            })
        
        # Get top players with rankings
        top_players = Player.query.filter(
            Player.world_ranking.isnot(None)
        ).order_by(Player.world_ranking.asc()).limit(20).all()
        
        for player in top_players:
            context['players'].append({
                'name': player.name,
                'world_ranking': player.world_ranking,
                'avg_score': player.avg_score,
                'recent_form': player.recent_form,
                'driving_distance': player.driving_distance,
                'putting_average': player.putting_average
            })
        
        # Get recent predictions
        recent_predictions = db.session.query(Prediction, Player, Tournament).join(
            Player, Prediction.player_id == Player.id
        ).join(
            Tournament, Prediction.tournament_id == Tournament.id
        ).order_by(Prediction.created_at.desc()).limit(15).all()
        
        for pred, player, tournament in recent_predictions:
            context['predictions'].append({
                'player_name': player.name,
                'tournament_name': tournament.name,
                'predicted_score': pred.predicted_score,
                'win_probability': pred.win_probability,
                'confidence_score': pred.confidence_score,
                'prediction_type': pred.prediction_type
            })
        
        # Get weather data for current tournaments  
        try:
            from services.weather_service import get_weather_data
            weather_data = get_weather_data()
            if weather_data.get('success'):
                context['weather'] = weather_data.get('current_conditions', [])
        except ImportError:
            # Weather service not available, use API directly
            context['weather'] = []
        
        # Summary for AI context
        context['summary'] = f"Current data includes {len(context['tournaments'])} tournaments, {len(context['players'])} players, {len(context['predictions'])} predictions, and weather data."
        
        return context
        
    except Exception as e:
        logging.error(f"Error gathering AI context: {e}")
        return {'summary': 'Limited data available due to context gathering error'}

def generate_ai_response(question, context_data, chat_history):
    """Generate AI response using data-driven analysis"""
    try:
        # First, try to use actual data to provide intelligent responses
        return get_intelligent_data_response(question, context_data)
            
    except Exception as e:
        logging.error(f"Error generating AI response: {e}")
        return get_fallback_ai_response(question, context_data)

def get_intelligent_data_response(question, context_data):
    """Generate intelligent responses using actual tournament and player data"""
    question_lower = question.lower()
    
    tournaments = context_data.get('tournaments', [])
    players = context_data.get('players', [])
    predictions = context_data.get('predictions', [])
    
    # First round leader questions
    if 'first round' in question_lower and 'leader' in question_lower:
        if not players:
            return "I don't have current player data available. Please refresh the data in the admin panel and try again."
        
        # Find players with good recent form and low average scores
        good_first_round_players = []
        for player in players[:15]:  # Top 15 ranked players
            if player.get('recent_form') and player.get('avg_score'):
                if player['recent_form'] > 3.0 and player['avg_score'] < 71.0:
                    good_first_round_players.append(player)
        
        if good_first_round_players:
            response = "Based on current data, here are the best first round leader candidates:\n\n"
            for i, player in enumerate(good_first_round_players[:5], 1):
                response += f"{i}. **{player['name']}** (World #{player['world_ranking']})\n"
                response += f"   - Average Score: {player['avg_score']:.1f}\n"
                response += f"   - Recent Form: {player['recent_form']:.1f}/5.0\n\n"
            
            response += "**Strategy:** Look for first round leader odds on these players. They have consistently low scoring and good recent form."
            return response
        
    # John Deere Classic specific questions
    elif 'john deere' in question_lower:
        current_tournament = None
        for t in tournaments:
            if 'john deere' in t['name'].lower():
                current_tournament = t
                break
        
        if current_tournament:
            response = f"**{current_tournament['name']} Analysis**\n\n"
            response += f"📅 Dates: {current_tournament['start_date']} to {current_tournament['end_date']}\n"
            response += f"🏌️ Course: {current_tournament['course']}\n"
            response += f"💰 Purse: ${current_tournament['purse']:,}\n\n"
            
            # Find predictions for this tournament
            tournament_predictions = [p for p in predictions if 'john deere' in p.get('tournament_name', '').lower()]
            
            if tournament_predictions:
                response += "**Top Predictions:**\n"
                for pred in tournament_predictions[:5]:
                    win_prob = pred['win_probability'] * 100 if pred['win_probability'] else 0
                    response += f"• {pred['player_name']}: {win_prob:.1f}% win probability\n"
            else:
                response += "**Recommended Players** (based on typical field):\n"
                response += "• Sepp Straka - Good course history\n"
                response += "• J.T. Poston - Strong recent form\n"
                response += "• Denny McCarthy - Consistent scorer\n"
            
            return response
    
    # General betting questions
    elif 'bet' in question_lower or 'pick' in question_lower:
        if predictions:
            response = "**Current Top Betting Picks:**\n\n"
            sorted_predictions = sorted(predictions, key=lambda x: x.get('win_probability', 0), reverse=True)
            
            for i, pred in enumerate(sorted_predictions[:5], 1):
                win_prob = pred['win_probability'] * 100 if pred['win_probability'] else 0
                confidence = pred['confidence_score'] * 100 if pred['confidence_score'] else 0
                
                response += f"{i}. **{pred['player_name']}** in {pred['tournament_name']}\n"
                response += f"   - Win Probability: {win_prob:.1f}%\n"
                response += f"   - Model Confidence: {confidence:.0f}%\n\n"
            
            response += "**Betting Strategy:** Focus on players with high model confidence and look for value in the odds."
            return response
    
    # Weather questions
    elif 'weather' in question_lower:
        return "Weather conditions significantly impact golf performance. Wind affects ball flight, rain softens greens (favoring approach players), and temperature affects ball distance. For specific current conditions, check the weather data in the tournament section."
    
    # Player comparison questions
    elif 'vs' in question_lower or 'compare' in question_lower:
        # Extract player names if possible
        words = question.split()
        potential_players = []
        for word in words:
            for player in players:
                if word.lower() in player['name'].lower():
                    potential_players.append(player)
        
        if len(potential_players) >= 2:
            p1, p2 = potential_players[0], potential_players[1]
            response = f"**{p1['name']} vs {p2['name']} Comparison:**\n\n"
            response += f"**{p1['name']}**\n"
            response += f"• World Ranking: #{p1['world_ranking']}\n"
            response += f"• Average Score: {p1.get('avg_score', 'N/A')}\n"
            response += f"• Recent Form: {p1.get('recent_form', 'N/A')}\n\n"
            response += f"**{p2['name']}**\n"
            response += f"• World Ranking: #{p2['world_ranking']}\n"
            response += f"• Average Score: {p2.get('avg_score', 'N/A')}\n"
            response += f"• Recent Form: {p2.get('recent_form', 'N/A')}\n\n"
            
            # Determine recommendation
            if p1['world_ranking'] < p2['world_ranking']:
                response += f"**Recommendation:** {p1['name']} has the higher ranking and may be the safer bet."
            else:
                response += f"**Recommendation:** {p2['name']} has the higher ranking and may be the safer bet."
            
            return response
    
    # Fallback for general questions
    return get_fallback_ai_response(question, context_data)

def format_tournaments_for_ai(tournaments):
    """Format tournament data for AI context"""
    if not tournaments:
        return "No tournament data available"
    
    formatted = []
    for t in tournaments[:3]:  # Top 3 upcoming
        formatted.append(f"- {t['name']} at {t['course']} ({t['start_date']} to {t['end_date']}) - ${t['purse']:,} purse")
    
    return "\n".join(formatted)

def format_players_for_ai(players):
    """Format player data for AI context"""
    if not players:
        return "No player data available"
    
    formatted = []
    for p in players[:10]:  # Top 10 players
        avg_score = f" (Avg: {p['avg_score']:.1f})" if p['avg_score'] else ""
        form = f" Form: {p['recent_form']:.1f}" if p['recent_form'] else ""
        formatted.append(f"- #{p['world_ranking']} {p['name']}{avg_score}{form}")
    
    return "\n".join(formatted)

def format_predictions_for_ai(predictions):
    """Format prediction data for AI context"""
    if not predictions:
        return "No predictions available"
    
    formatted = []
    for p in predictions[:8]:  # Top 8 predictions
        win_prob = f"{p['win_probability']*100:.1f}%" if p['win_probability'] else "N/A"
        confidence = f" (Confidence: {p['confidence_score']*100:.0f}%)" if p['confidence_score'] else ""
        formatted.append(f"- {p['player_name']} in {p['tournament_name']}: {win_prob} win probability{confidence}")
    
    return "\n".join(formatted)

def format_weather_for_ai(weather_data):
    """Format weather data for AI context"""
    if not weather_data:
        return "No weather data available"
    
    # Weather data is expected to be a list or dict with course conditions
    if isinstance(weather_data, list) and weather_data:
        return f"Current conditions: {weather_data[0].get('description', 'Unknown')}"
    elif isinstance(weather_data, dict):
        return f"Current conditions: {weather_data.get('description', 'Unknown')}"
    
    return "Weather data format not recognized"

def format_chat_history_for_ai(chat_history):
    """Format chat history for AI context"""
    if not chat_history:
        return "No previous conversation"
    
    formatted = []
    for msg in chat_history[-6:]:  # Last 6 messages
        role = msg.get('role', 'unknown')
        content = msg.get('content', '')[:100]  # Truncate long messages
        formatted.append(f"{role.title()}: {content}")
    
    return "\n".join(formatted)

def get_fallback_ai_response(question, context_data):
    """Provide fallback response when AI service is unavailable"""
    current_tournament = None
    if context_data.get('tournaments'):
        current_tournament = context_data['tournaments'][0]
    
    if 'john deere' in question.lower() or 'upcoming' in question.lower():
        if current_tournament:
            return f"Based on current data, the {current_tournament['name']} is upcoming ({current_tournament['start_date']} to {current_tournament['end_date']}). " \
                   f"This tournament has a ${current_tournament['purse']:,} purse. For specific betting recommendations, I'd need the AI service to analyze " \
                   f"the full player field and predictions. Please try your question again in a moment."
        else:
            return "I don't have current tournament information available. Please check the tournament data refresh and try again."
    
    elif 'weather' in question.lower():
        return "Weather conditions are important for golf betting. I can see current weather data in the system, " \
               "but I need the AI service to properly analyze how conditions will impact player performance. Please try again shortly."
    
    elif 'player' in question.lower() or 'bet' in question.lower():
        player_count = len(context_data.get('players', []))
        prediction_count = len(context_data.get('predictions', []))
        return f"I have data on {player_count} players and {prediction_count} recent predictions. " \
               f"For detailed betting analysis and player comparisons, I need the AI service to process this information. Please try your question again."
    
    else:
        return "I'm ready to help with golf betting questions! I have access to tournament data, player statistics, " \
               "predictions, and weather information. The AI analysis service is temporarily unavailable, but please try your question again."

# Scheduled tasks
def schedule_daily_tasks():
    """Schedule daily tasks for data updates and predictions"""
    try:
        # Refresh tournament data every 6 hours
        scheduler.add_job(
            func=refresh_tournament_data,
            trigger="cron",
            hour='*/6',
            minute=0,
            id='tournament_data_refresh'
        )
        
        # Refresh player rankings daily at 5 AM
        scheduler.add_job(
            func=refresh_player_rankings,
            trigger="cron",
            hour=5,
            minute=0,
            id='daily_player_rankings'
        )
        
        # Train ML model daily at 6 AM
        scheduler.add_job(
            func=train_model,
            trigger="cron",
            hour=6,
            minute=0,
            id='daily_model_training'
        )
        
        # Full data refresh (tournaments, players, predictions) daily at 4 AM
        scheduler.add_job(
            func=full_data_refresh,
            trigger="cron",
            hour=4,
            minute=0,
            id='full_data_refresh'
        )
        
        # Send Telegram picks daily at 8 AM
        scheduler.add_job(
            func=send_daily_picks,
            trigger="cron",
            hour=8,
            minute=0,
            id='daily_telegram_picks'
        )
        
        logging.info("Scheduled daily tasks successfully")
    except Exception as e:
        logging.error(f"Error scheduling daily tasks: {e}")

# Initialize scheduled tasks
schedule_daily_tasks()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
