from app import db
from flask_login import UserMixin
from datetime import datetime
import uuid

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256))
    telegram_chat_id = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    predictions = db.relationship('Prediction', backref='user', lazy=True)
    bets = db.relationship('Bet', backref='user', lazy=True)

class Tournament(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    course = db.Column(db.String(200))
    start_date = db.Column(db.DateTime)
    end_date = db.Column(db.DateTime)
    purse = db.Column(db.Float)
    status = db.Column(db.String(50), default='upcoming')
    weather_conditions = db.Column(db.Text)
    
    # Relationships
    predictions = db.relationship('Prediction', backref='tournament', lazy=True)

class Player(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    world_ranking = db.Column(db.Integer)
    avg_score = db.Column(db.Float)
    driving_distance = db.Column(db.Float)
    driving_accuracy = db.Column(db.Float)
    greens_in_regulation = db.Column(db.Float)
    putting_average = db.Column(db.Float)
    recent_form = db.Column(db.Float)  # Score based on recent performance
    
    # Relationships
    predictions = db.relationship('Prediction', backref='player', lazy=True)

class Prediction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    tournament_id = db.Column(db.Integer, db.ForeignKey('tournament.id'), nullable=False)
    player_id = db.Column(db.Integer, db.ForeignKey('player.id'), nullable=False)
    predicted_score = db.Column(db.Float)
    win_probability = db.Column(db.Float)
    confidence_score = db.Column(db.Float)
    prediction_type = db.Column(db.String(50))  # 'win', 'top_5', 'top_10', 'cut'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    model_version = db.Column(db.String(50))

class Bet(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    tournament_id = db.Column(db.Integer, db.ForeignKey('tournament.id'))
    player_name = db.Column(db.String(100))
    bet_type = db.Column(db.String(50))  # 'win', 'top_5', 'top_10', 'cut'
    odds = db.Column(db.Float)
    stake = db.Column(db.Float)
    potential_payout = db.Column(db.Float)
    status = db.Column(db.String(20), default='pending')  # 'pending', 'won', 'lost'
    placed_at = db.Column(db.DateTime, default=datetime.utcnow)
    settled_at = db.Column(db.DateTime)

class ModelPerformance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    model_version = db.Column(db.String(50), nullable=False)
    tournament_id = db.Column(db.Integer, db.ForeignKey('tournament.id'))
    accuracy = db.Column(db.Float)
    precision = db.Column(db.Float)
    recall = db.Column(db.Float)
    f1_score = db.Column(db.Float)
    total_predictions = db.Column(db.Integer)
    correct_predictions = db.Column(db.Integer)
    evaluated_at = db.Column(db.DateTime, default=datetime.utcnow)

class TournamentPlayer(db.Model):
    __tablename__ = 'tournament_players'
    id = db.Column(db.Integer, primary_key=True)
    tournament_id = db.Column(db.Integer, db.ForeignKey('tournament.id'), nullable=False)
    player_id = db.Column(db.Integer, db.ForeignKey('player.id'), nullable=False)
    status = db.Column(db.String(20), default='committed')  # committed, withdrawn, alternate
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Add unique constraint to prevent duplicate entries
    __table_args__ = (db.UniqueConstraint('tournament_id', 'player_id', name='unique_tournament_player'),)
