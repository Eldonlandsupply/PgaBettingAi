# PGA Betting AI - System Architecture

## Overview

This is a Flask-based web application that provides AI-powered golf betting predictions and analysis. The system combines machine learning models, external APIs, and real-time data to help users make informed betting decisions on PGA tournaments.

## System Architecture

### Backend Framework
- **Flask**: Core web framework with SQLAlchemy for database operations
- **APScheduler**: Background task scheduling for data updates and automated processes
- **ProxyFix**: Middleware for proper handling of proxy headers in production

### Frontend Architecture
- **Server-side rendering**: Flask templates with Jinja2 templating engine
- **Bootstrap**: Dark theme CSS framework for responsive UI
- **Chart.js**: Client-side data visualization for charts and graphs
- **Font Awesome**: Icon library for UI elements

### Database Architecture
- **SQLAlchemy ORM**: Database abstraction layer with declarative base
- **SQLite**: Default local development database
- **PostgreSQL**: Production database (configurable via DATABASE_URL)
- **Connection pooling**: Configured for production reliability

## Key Components

### Data Models
- **User**: User accounts with authentication and preferences
- **Tournament**: PGA tournament information and metadata
- **Player**: Golf player statistics and performance metrics
- **Prediction**: AI-generated predictions linking users, tournaments, and players
- **Bet**: User betting history and tracking

### Service Layer
- **PGA API Service**: Integration with golf data providers (DataGolf API)
- **ML Models Service**: Machine learning prediction engine using scikit-learn
- **Odds Analysis Service**: Betting odds comparison and value calculation
- **Weather Service**: Weather impact analysis using OpenWeatherMap API
- **ChatGPT Service**: AI-powered betting analysis using OpenAI API
- **User Service**: Authentication and user management
- **Analytics Service**: Performance reporting and statistics
- **Telegram Bot Service**: Automated notifications and picks delivery

### Machine Learning Pipeline
- **RandomForestRegressor**: Score prediction model
- **GradientBoostingClassifier**: Win probability classifier
- **Feature engineering**: Player stats, course history, weather factors
- **Model persistence**: Joblib for model storage and loading

## Data Flow

1. **Data Collection**: Scheduled tasks fetch tournament data, player statistics, and weather information
2. **Feature Engineering**: Raw data is processed into ML-ready features
3. **Prediction Generation**: ML models generate score and win probability predictions
4. **Odds Analysis**: Current betting odds are compared against model predictions to identify value
5. **User Interface**: Predictions and recommendations are presented through web dashboard
6. **Notifications**: Telegram bot delivers daily picks and updates to subscribed users

## External Dependencies

### APIs and Services
- **DataGolf API**: Primary source for PGA tournament and player data
- **OpenWeatherMap API**: Weather data for course conditions
- **The Odds API**: Current betting odds from multiple sportsbooks
- **OpenAI API**: ChatGPT integration for advanced analysis
- **Telegram Bot API**: Automated messaging and notifications

### Third-party Libraries
- **scikit-learn**: Machine learning algorithms and preprocessing
- **pandas/numpy**: Data manipulation and numerical computing
- **requests**: HTTP client for API integrations
- **APScheduler**: Background job scheduling

## Deployment Strategy

### Environment Configuration
- Environment variables for API keys and database connections
- Separate configurations for development and production
- Secret key management for session security

### Database Setup
- Automatic table creation on application startup
- Migration support through SQLAlchemy
- Connection pooling and health checks for production

### Background Services
- Scheduler initialization for automated data updates
- Graceful shutdown handling with atexit registration
- Error handling and logging for service reliability

## Changelog
- June 30, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.