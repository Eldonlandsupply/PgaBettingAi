import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
from app import db
from models import User, Tournament, Player, Prediction, Bet, ModelPerformance
from sqlalchemy import func

def generate_report():
    """Generate comprehensive analytics report"""
    try:
        report = {
            'success': True,
            'generated_at': datetime.now().isoformat(),
            'report_period': get_report_period(),
            'summary': generate_summary_stats(),
            'user_analytics': generate_user_analytics(),
            'prediction_analytics': generate_prediction_analytics(),
            'betting_analytics': generate_betting_analytics(),
            'model_performance': analyze_model_performance(),
            'trends': analyze_trends(),
            'recommendations': generate_recommendations()
        }
        
        return report
        
    except Exception as e:
        logging.error(f"Error generating analytics report: {e}")
        return {
            'success': False,
            'error': str(e),
            'generated_at': datetime.now().isoformat()
        }

def get_report_period():
    """Get the reporting period"""
    end_date = datetime.now()
    start_date = end_date - timedelta(days=30)  # Last 30 days
    
    return {
        'start_date': start_date.isoformat(),
        'end_date': end_date.isoformat(),
        'period_description': 'Last 30 days'
    }

def generate_summary_stats():
    """Generate high-level summary statistics"""
    try:
        # User statistics
        total_users = User.query.count()
        active_users = User.query.filter_by(is_active=True).count()
        new_users_30d = User.query.filter(
            User.created_at >= datetime.now() - timedelta(days=30)
        ).count()
        
        # Prediction statistics
        total_predictions = Prediction.query.count()
        predictions_30d = Prediction.query.filter(
            Prediction.created_at >= datetime.now() - timedelta(days=30)
        ).count()
        
        # Betting statistics
        total_bets = Bet.query.count()
        bets_30d = Bet.query.filter(
            Bet.placed_at >= datetime.now() - timedelta(days=30)
        ).count()
        
        # Financial statistics
        total_volume = db.session.query(func.sum(Bet.stake)).scalar() or 0
        volume_30d = db.session.query(func.sum(Bet.stake)).filter(
            Bet.placed_at >= datetime.now() - timedelta(days=30)
        ).scalar() or 0
        
        return {
            'users': {
                'total': total_users,
                'active': active_users,
                'new_last_30d': new_users_30d,
                'activation_rate': round((active_users / total_users) * 100, 1) if total_users > 0 else 0
            },
            'predictions': {
                'total': total_predictions,
                'last_30d': predictions_30d,
                'daily_average': round(predictions_30d / 30, 1)
            },
            'betting': {
                'total_bets': total_bets,
                'bets_last_30d': bets_30d,
                'total_volume': round(total_volume, 2),
                'volume_last_30d': round(volume_30d, 2),
                'avg_bet_size': round(volume_30d / bets_30d, 2) if bets_30d > 0 else 0
            }
        }
        
    except Exception as e:
        logging.error(f"Error generating summary stats: {e}")
        return {}

def generate_user_analytics():
    """Generate user behavior analytics"""
    try:
        # User engagement metrics
        engagement_data = calculate_user_engagement()
        
        # User segmentation
        user_segments = segment_users()
        
        # Geographic distribution (if available)
        geographic_dist = analyze_geographic_distribution()
        
        return {
            'engagement': engagement_data,
            'segmentation': user_segments,
            'geographic_distribution': geographic_dist,
            'retention_metrics': calculate_retention_metrics()
        }
        
    except Exception as e:
        logging.error(f"Error generating user analytics: {e}")
        return {}

def calculate_user_engagement():
    """Calculate user engagement metrics"""
    try:
        thirty_days_ago = datetime.now() - timedelta(days=30)
        
        # Active users by period
        daily_active = User.query.join(Prediction).filter(
            Prediction.created_at >= datetime.now() - timedelta(days=1)
        ).distinct().count()
        
        weekly_active = User.query.join(Prediction).filter(
            Prediction.created_at >= datetime.now() - timedelta(days=7)
        ).distinct().count()
        
        monthly_active = User.query.join(Prediction).filter(
            Prediction.created_at >= thirty_days_ago
        ).distinct().count()
        
        # Average predictions per user
        avg_predictions = db.session.query(func.avg(
            func.count(Prediction.id)
        )).select_from(Prediction).filter(
            Prediction.created_at >= thirty_days_ago
        ).group_by(Prediction.user_id).scalar() or 0
        
        return {
            'daily_active_users': daily_active,
            'weekly_active_users': weekly_active,
            'monthly_active_users': monthly_active,
            'avg_predictions_per_user': round(float(avg_predictions), 1)
        }
        
    except Exception as e:
        logging.error(f"Error calculating engagement: {e}")
        return {}

def segment_users():
    """Segment users based on behavior"""
    try:
        # Define user segments based on activity
        segments = {
            'power_users': 0,      # >20 predictions/month
            'regular_users': 0,    # 5-20 predictions/month
            'casual_users': 0,     # 1-5 predictions/month
            'inactive_users': 0    # 0 predictions/month
        }
        
        thirty_days_ago = datetime.now() - timedelta(days=30)
        
        # Query user prediction counts
        user_prediction_counts = db.session.query(
            Prediction.user_id,
            func.count(Prediction.id).label('prediction_count')
        ).filter(
            Prediction.created_at >= thirty_days_ago
        ).group_by(Prediction.user_id).all()
        
        for user_id, count in user_prediction_counts:
            if count > 20:
                segments['power_users'] += 1
            elif count >= 5:
                segments['regular_users'] += 1
            elif count >= 1:
                segments['casual_users'] += 1
        
        # Count inactive users
        active_user_ids = [uid for uid, _ in user_prediction_counts]
        total_users = User.query.count()
        segments['inactive_users'] = total_users - len(active_user_ids)
        
        return segments
        
    except Exception as e:
        logging.error(f"Error segmenting users: {e}")
        return {}

def analyze_geographic_distribution():
    """Analyze geographic distribution of users"""
    # This would require additional user location data
    # For now, return placeholder structure
    return {
        'note': 'Geographic data not available',
        'regions': {}
    }

def calculate_retention_metrics():
    """Calculate user retention metrics"""
    try:
        # Simple retention calculation based on user activity
        now = datetime.now()
        
        # Users who signed up 30 days ago and are still active
        thirty_days_ago = now - timedelta(days=30)
        sixty_days_ago = now - timedelta(days=60)
        
        cohort_users = User.query.filter(
            User.created_at.between(sixty_days_ago, thirty_days_ago)
        ).all()
        
        if not cohort_users:
            return {'retention_rate_30d': 0, 'note': 'Insufficient data for retention analysis'}
        
        # Check how many are still active (made predictions in last 7 days)
        seven_days_ago = now - timedelta(days=7)
        active_cohort_users = 0
        
        for user in cohort_users:
            recent_activity = Prediction.query.filter(
                Prediction.user_id == user.id,
                Prediction.created_at >= seven_days_ago
            ).first()
            
            if recent_activity:
                active_cohort_users += 1
        
        retention_rate = (active_cohort_users / len(cohort_users)) * 100
        
        return {
            'retention_rate_30d': round(retention_rate, 1),
            'cohort_size': len(cohort_users),
            'retained_users': active_cohort_users
        }
        
    except Exception as e:
        logging.error(f"Error calculating retention: {e}")
        return {}

def generate_prediction_analytics():
    """Generate prediction analytics"""
    try:
        thirty_days_ago = datetime.now() - timedelta(days=30)
        
        # Prediction type distribution
        type_distribution = db.session.query(
            Prediction.prediction_type,
            func.count(Prediction.id).label('count')
        ).filter(
            Prediction.created_at >= thirty_days_ago
        ).group_by(Prediction.prediction_type).all()
        
        # Confidence score analysis
        avg_confidence = db.session.query(
            func.avg(Prediction.confidence_score)
        ).filter(
            Prediction.created_at >= thirty_days_ago
        ).scalar() or 0
        
        # Most predicted players
        popular_players = db.session.query(
            Prediction.player_id,
            func.count(Prediction.id).label('prediction_count')
        ).filter(
            Prediction.created_at >= thirty_days_ago
        ).group_by(Prediction.player_id).order_by(
            func.count(Prediction.id).desc()
        ).limit(10).all()
        
        return {
            'prediction_types': dict(type_distribution),
            'average_confidence': round(float(avg_confidence), 2),
            'most_predicted_players': [
                {'player_id': pid, 'prediction_count': count} 
                for pid, count in popular_players
            ],
            'total_predictions_30d': sum(count for _, count in type_distribution)
        }
        
    except Exception as e:
        logging.error(f"Error generating prediction analytics: {e}")
        return {}

def generate_betting_analytics():
    """Generate betting analytics"""
    try:
        thirty_days_ago = datetime.now() - timedelta(days=30)
        
        # Betting volume and frequency
        betting_volume = db.session.query(
            func.sum(Bet.stake),
            func.count(Bet.id),
            func.avg(Bet.stake)
        ).filter(
            Bet.placed_at >= thirty_days_ago
        ).first()
        
        total_volume, total_bets, avg_stake = betting_volume or (0, 0, 0)
        
        # Win/loss analysis
        win_loss = db.session.query(
            Bet.status,
            func.count(Bet.id).label('count'),
            func.sum(Bet.stake).label('total_stake'),
            func.sum(Bet.potential_payout).label('total_payout')
        ).filter(
            Bet.placed_at >= thirty_days_ago,
            Bet.status.in_(['won', 'lost'])
        ).group_by(Bet.status).all()
        
        # Bet type distribution
        bet_types = db.session.query(
            Bet.bet_type,
            func.count(Bet.id).label('count')
        ).filter(
            Bet.placed_at >= thirty_days_ago
        ).group_by(Bet.bet_type).all()
        
        # Calculate ROI
        total_stakes = sum(stake for _, _, stake, _ in win_loss)
        total_winnings = sum(payout for status, _, _, payout in win_loss if status == 'won')
        roi = ((total_winnings - total_stakes) / total_stakes * 100) if total_stakes > 0 else 0
        
        return {
            'volume_metrics': {
                'total_volume': round(float(total_volume or 0), 2),
                'total_bets': total_bets or 0,
                'average_stake': round(float(avg_stake or 0), 2)
            },
            'performance_metrics': {
                'roi': round(roi, 2),
                'total_winnings': round(total_winnings, 2),
                'total_stakes': round(total_stakes, 2),
                'profit_loss': round(total_winnings - total_stakes, 2)
            },
            'bet_type_distribution': dict(bet_types),
            'win_loss_breakdown': {
                status: {
                    'count': count,
                    'total_stake': float(stake),
                    'total_payout': float(payout)
                } for status, count, stake, payout in win_loss
            }
        }
        
    except Exception as e:
        logging.error(f"Error generating betting analytics: {e}")
        return {}

def analyze_model_performance():
    """Analyze ML model performance metrics"""
    try:
        # Get latest model performance data
        latest_performance = ModelPerformance.query.order_by(
            ModelPerformance.evaluated_at.desc()
        ).first()
        
        if not latest_performance:
            return {'note': 'No model performance data available'}
        
        # Historical performance trend
        historical_performance = ModelPerformance.query.order_by(
            ModelPerformance.evaluated_at.desc()
        ).limit(10).all()
        
        return {
            'latest_metrics': {
                'accuracy': latest_performance.accuracy,
                'precision': latest_performance.precision,
                'recall': latest_performance.recall,
                'f1_score': latest_performance.f1_score,
                'model_version': latest_performance.model_version,
                'evaluated_at': latest_performance.evaluated_at.isoformat()
            },
            'historical_trend': [
                {
                    'date': perf.evaluated_at.isoformat(),
                    'accuracy': perf.accuracy,
                    'version': perf.model_version
                } for perf in historical_performance
            ]
        }
        
    except Exception as e:
        logging.error(f"Error analyzing model performance: {e}")
        return {}

def analyze_trends():
    """Analyze usage and performance trends"""
    try:
        # Daily usage trend over last 30 days
        daily_trends = []
        
        for i in range(30):
            date = datetime.now() - timedelta(days=i)
            day_start = date.replace(hour=0, minute=0, second=0, microsecond=0)
            day_end = day_start + timedelta(days=1)
            
            daily_predictions = Prediction.query.filter(
                Prediction.created_at.between(day_start, day_end)
            ).count()
            
            daily_bets = Bet.query.filter(
                Bet.placed_at.between(day_start, day_end)
            ).count()
            
            daily_trends.append({
                'date': day_start.isoformat()[:10],
                'predictions': daily_predictions,
                'bets': daily_bets
            })
        
        # Weekly comparison
        this_week = datetime.now() - timedelta(days=7)
        last_week = datetime.now() - timedelta(days=14)
        
        this_week_predictions = Prediction.query.filter(
            Prediction.created_at >= this_week
        ).count()
        
        last_week_predictions = Prediction.query.filter(
            Prediction.created_at.between(last_week, this_week)
        ).count()
        
        week_over_week = ((this_week_predictions - last_week_predictions) / 
                         last_week_predictions * 100) if last_week_predictions > 0 else 0
        
        return {
            'daily_usage': daily_trends[-7:],  # Last 7 days
            'weekly_comparison': {
                'this_week': this_week_predictions,
                'last_week': last_week_predictions,
                'percent_change': round(week_over_week, 1)
            }
        }
        
    except Exception as e:
        logging.error(f"Error analyzing trends: {e}")
        return {}

def generate_recommendations():
    """Generate actionable recommendations based on analytics"""
    try:
        recommendations = []
        
        # Get summary stats for analysis
        summary = generate_summary_stats()
        user_analytics = generate_user_analytics()
        
        # User engagement recommendations
        if user_analytics.get('engagement', {}).get('monthly_active_users', 0) < summary.get('users', {}).get('total', 0) * 0.5:
            recommendations.append({
                'type': 'USER_ENGAGEMENT',
                'priority': 'HIGH',
                'title': 'Improve User Engagement',
                'description': 'Less than 50% of users are active monthly. Consider implementing engagement features.',
                'actions': [
                    'Add email notifications for tournament predictions',
                    'Implement user achievement system',
                    'Create weekly prediction challenges'
                ]
            })
        
        # Model performance recommendations
        model_perf = analyze_model_performance()
        if model_perf.get('latest_metrics', {}).get('accuracy', 0) < 0.6:
            recommendations.append({
                'type': 'MODEL_IMPROVEMENT',
                'priority': 'HIGH',
                'title': 'Improve Prediction Model',
                'description': 'Model accuracy is below 60%. Consider retraining with more data.',
                'actions': [
                    'Collect more historical tournament data',
                    'Feature engineering for weather impact',
                    'Implement ensemble modeling'
                ]
            })
        
        # Betting recommendations
        betting_analytics = generate_betting_analytics()
        roi = betting_analytics.get('performance_metrics', {}).get('roi', 0)
        if roi < 0:
            recommendations.append({
                'type': 'BETTING_STRATEGY',
                'priority': 'MEDIUM',
                'title': 'Improve Betting Strategy',
                'description': 'Overall ROI is negative. Review betting recommendations.',
                'actions': [
                    'Implement stricter value betting criteria',
                    'Add bankroll management features',
                    'Improve odds analysis algorithms'
                ]
            })
        
        # Growth recommendations
        new_users_rate = summary.get('users', {}).get('new_last_30d', 0)
        if new_users_rate < 10:
            recommendations.append({
                'type': 'USER_GROWTH',
                'priority': 'MEDIUM',
                'title': 'Increase User Acquisition',
                'description': 'Low new user acquisition rate. Focus on growth strategies.',
                'actions': [
                    'Implement referral program',
                    'Improve SEO and content marketing',
                    'Partner with golf content creators'
                ]
            })
        
        return recommendations
        
    except Exception as e:
        logging.error(f"Error generating recommendations: {e}")
        return []
