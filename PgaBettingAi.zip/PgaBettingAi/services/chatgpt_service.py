import openai
import os
import logging
from datetime import datetime
import json

# OpenAI API configuration
openai.api_key = os.getenv('OPENAI_API_KEY', 'demo_key')

def analyze_with_chatgpt(prompt):
    """Analyze golf betting scenarios using ChatGPT"""
    try:
        if not prompt or len(prompt.strip()) == 0:
            return {'success': False, 'error': 'Empty prompt provided'}
        
        # Enhance prompt with golf betting context
        enhanced_prompt = create_enhanced_prompt(prompt)
        
        # Make API call to OpenAI
        response = openai.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": get_system_message()},
                {"role": "user", "content": enhanced_prompt}
            ],
            max_tokens=1000,
            temperature=0.7
        )
        
        analysis = response.choices[0].message.content
        
        # Parse and structure the response
        structured_analysis = structure_gpt_response(analysis, prompt)
        
        return {
            'success': True,
            'analysis': structured_analysis,
            'raw_response': analysis,
            'prompt': prompt,
            'model': 'gpt-3.5-turbo',
            'generated_at': datetime.now().isoformat()
        }
        
    except openai.RateLimitError:
        logging.error("OpenAI API rate limit exceeded")
        return get_fallback_analysis(prompt, "Rate limit exceeded")
    except openai.AuthenticationError:
        logging.error("OpenAI API authentication failed")
        return get_fallback_analysis(prompt, "Authentication failed")
    except Exception as e:
        logging.error(f"Error in ChatGPT analysis: {e}")
        return get_fallback_analysis(prompt, str(e))

def get_system_message():
    """Get system message to set context for ChatGPT"""
    return """You are an expert golf betting analyst with deep knowledge of PGA Tour statistics, 
    player performance metrics, course analysis, and betting strategy. Provide detailed, 
    data-driven insights for golf betting decisions. Focus on:
    
    1. Player form and recent performance
    2. Course fit and historical performance
    3. Weather impact on play style
    4. Betting value and odds analysis
    5. Risk assessment and bankroll management
    
    Always provide specific, actionable recommendations with reasoning."""

def create_enhanced_prompt(user_prompt):
    """Enhance user prompt with additional context"""
    try:
        enhanced = f"""
        Golf Betting Analysis Request:
        
        User Question: {user_prompt}
        
        Please provide a comprehensive analysis including:
        1. Key factors to consider
        2. Player recommendations with reasoning
        3. Betting strategy suggestions
        4. Risk assessment
        5. Specific odds or bet types to target
        
        Consider current PGA Tour trends, course conditions, and recent form when applicable.
        """
        
        return enhanced
        
    except Exception as e:
        logging.error(f"Error enhancing prompt: {e}")
        return user_prompt

def structure_gpt_response(analysis, original_prompt):
    """Structure ChatGPT response into organized sections"""
    try:
        # Split analysis into logical sections
        sections = parse_analysis_sections(analysis)
        
        # Extract key insights
        key_insights = extract_key_insights(analysis)
        
        # Generate confidence score
        confidence_score = calculate_analysis_confidence(analysis)
        
        return {
            'summary': extract_summary(analysis),
            'key_insights': key_insights,
            'sections': sections,
            'confidence_score': confidence_score,
            'actionable_recommendations': extract_recommendations(analysis),
            'risk_warnings': extract_risk_warnings(analysis)
        }
        
    except Exception as e:
        logging.error(f"Error structuring GPT response: {e}")
        return {
            'summary': analysis[:200] + "..." if len(analysis) > 200 else analysis,
            'raw_analysis': analysis
        }

def parse_analysis_sections(analysis):
    """Parse analysis into logical sections"""
    try:
        sections = {}
        
        # Look for numbered sections or clear headers
        if "1." in analysis and "2." in analysis:
            sections['factors'] = extract_between_markers(analysis, "1.", "2.")
            sections['recommendations'] = extract_between_markers(analysis, "2.", "3.")
            if "3." in analysis:
                sections['strategy'] = extract_between_markers(analysis, "3.", "4.")
            if "4." in analysis:
                sections['risk_assessment'] = extract_between_markers(analysis, "4.", "5.")
        else:
            # Fallback: split by paragraphs
            paragraphs = analysis.split('\n\n')
            for i, paragraph in enumerate(paragraphs):
                sections[f'section_{i+1}'] = paragraph.strip()
        
        return sections
        
    except Exception as e:
        logging.error(f"Error parsing sections: {e}")
        return {'full_analysis': analysis}

def extract_between_markers(text, start_marker, end_marker):
    """Extract text between two markers"""
    try:
        start_idx = text.find(start_marker)
        end_idx = text.find(end_marker)
        
        if start_idx != -1 and end_idx != -1:
            return text[start_idx:end_idx].strip()
        elif start_idx != -1:
            return text[start_idx:].strip()
        else:
            return ""
            
    except Exception:
        return ""

def extract_key_insights(analysis):
    """Extract key insights from the analysis"""
    try:
        insights = []
        
        # Look for key insight indicators
        insight_indicators = [
            "key factor", "important", "critical", "essential", "significant",
            "recommendation", "suggest", "advise", "consider"
        ]
        
        sentences = analysis.split('. ')
        for sentence in sentences:
            for indicator in insight_indicators:
                if indicator.lower() in sentence.lower():
                    insights.append(sentence.strip() + '.')
                    break
        
        # Remove duplicates and limit to top 5
        unique_insights = list(dict.fromkeys(insights))
        return unique_insights[:5]
        
    except Exception as e:
        logging.error(f"Error extracting insights: {e}")
        return []

def calculate_analysis_confidence(analysis):
    """Calculate confidence score for the analysis"""
    try:
        confidence_indicators = {
            'high': ['strongly', 'definitely', 'clearly', 'certain', 'confident'],
            'medium': ['likely', 'probably', 'suggest', 'indicate', 'seems'],
            'low': ['might', 'could', 'possibly', 'perhaps', 'uncertain']
        }
        
        text_lower = analysis.lower()
        
        high_count = sum(text_lower.count(word) for word in confidence_indicators['high'])
        medium_count = sum(text_lower.count(word) for word in confidence_indicators['medium'])
        low_count = sum(text_lower.count(word) for word in confidence_indicators['low'])
        
        total_indicators = high_count + medium_count + low_count
        
        if total_indicators == 0:
            return 0.7  # Default medium confidence
        
        # Calculate weighted confidence
        confidence = (high_count * 1.0 + medium_count * 0.6 + low_count * 0.3) / total_indicators
        return round(confidence, 2)
        
    except Exception as e:
        logging.error(f"Error calculating confidence: {e}")
        return 0.5

def extract_summary(analysis):
    """Extract a concise summary from the analysis"""
    try:
        # Take the first paragraph or first 150 characters
        paragraphs = analysis.split('\n\n')
        if paragraphs:
            summary = paragraphs[0].strip()
        else:
            summary = analysis[:150] + "..." if len(analysis) > 150 else analysis
        
        return summary
        
    except Exception:
        return "Analysis summary unavailable"

def extract_recommendations(analysis):
    """Extract actionable recommendations"""
    try:
        recommendations = []
        
        # Look for recommendation patterns
        recommendation_patterns = [
            "recommend", "suggest", "advise", "consider", "target", 
            "bet on", "avoid", "focus on", "look for"
        ]
        
        sentences = analysis.split('. ')
        for sentence in sentences:
            for pattern in recommendation_patterns:
                if pattern.lower() in sentence.lower():
                    recommendations.append(sentence.strip() + '.')
                    break
        
        # Clean and deduplicate
        unique_recommendations = list(dict.fromkeys(recommendations))
        return unique_recommendations[:3]  # Top 3 recommendations
        
    except Exception as e:
        logging.error(f"Error extracting recommendations: {e}")
        return []

def extract_risk_warnings(analysis):
    """Extract risk warnings from the analysis"""
    try:
        warnings = []
        
        risk_indicators = [
            "risk", "danger", "warning", "caution", "avoid", "risky", 
            "volatile", "uncertain", "unpredictable"
        ]
        
        sentences = analysis.split('. ')
        for sentence in sentences:
            for indicator in risk_indicators:
                if indicator.lower() in sentence.lower():
                    warnings.append(sentence.strip() + '.')
                    break
        
        # Remove duplicates
        unique_warnings = list(dict.fromkeys(warnings))
        return unique_warnings[:2]  # Top 2 warnings
        
    except Exception as e:
        logging.error(f"Error extracting warnings: {e}")
        return []

def get_fallback_analysis(prompt, error_reason):
    """Provide fallback analysis when ChatGPT is unavailable"""
    fallback_insights = [
        "Consider recent player form and world ranking trends",
        "Analyze course fit based on player strengths",
        "Factor in weather conditions for the tournament",
        "Review historical performance at the venue",
        "Assess betting odds for value opportunities"
    ]
    
    return {
        'success': False,
        'error': f'ChatGPT analysis unavailable: {error_reason}',
        'analysis': {
            'summary': 'ChatGPT analysis is currently unavailable. Use standard golf analysis principles.',
            'key_insights': fallback_insights,
            'sections': {
                'fallback_advice': 'Focus on fundamental golf analysis: recent form, course fit, weather impact, and value betting opportunities.'
            },
            'confidence_score': 0.3,
            'actionable_recommendations': [
                'Use statistical analysis for player selection',
                'Consider course history and playing style fit',
                'Monitor weather conditions and their impact'
            ],
            'risk_warnings': [
                'AI analysis unavailable - rely on traditional analysis methods'
            ]
        },
        'prompt': prompt,
        'generated_at': datetime.now().isoformat()
    }

def analyze_tournament_preview(tournament_data, player_data, weather_data):
    """Generate tournament preview analysis using ChatGPT"""
    try:
        # Create comprehensive tournament analysis prompt
        preview_prompt = f"""
        Provide a comprehensive tournament preview analysis for the upcoming PGA tournament.
        
        Tournament Details:
        - Name: {tournament_data.get('name', 'Current Tournament')}
        - Course: {tournament_data.get('course', 'TBD')}
        - Field strength and key players to watch
        
        Weather Conditions:
        - Current conditions affecting play
        - Impact on scoring and strategy
        
        Key Analysis Points:
        1. Course setup and what type of player succeeds here
        2. Top contenders and dark horses
        3. Betting strategy recommendations
        4. Weather impact on player selection
        5. Value bets and avoids
        
        Provide specific player names, betting recommendations, and reasoning.
        """
        
        return analyze_with_chatgpt(preview_prompt)
        
    except Exception as e:
        logging.error(f"Error in tournament preview analysis: {e}")
        return get_fallback_analysis(preview_prompt, str(e))
