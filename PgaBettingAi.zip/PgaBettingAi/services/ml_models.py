import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor, GradientBoostingClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, accuracy_score, classification_report
import joblib
import os
import logging
from datetime import datetime
from .pga_api import get_player_stats, get_historical_data

# Model storage path
MODEL_DIR = 'models'
if not os.path.exists(MODEL_DIR):
    os.makedirs(MODEL_DIR)

class PGAPredictionModel:
    def __init__(self):
        self.score_model = None
        self.win_model = None
        self.scaler = StandardScaler()
        self.feature_columns = [
            'world_ranking', 'avg_score', 'driving_distance', 
            'driving_accuracy', 'greens_in_regulation', 'putting_average',
            'recent_form', 'course_history_avg', 'weather_factor'
        ]
        
    def prepare_features(self, player_data, tournament_data=None, weather_data=None):
        """Prepare feature matrix from player and tournament data"""
        try:
            features = []
            
            for player in player_data:
                feature_row = [
                    player.get('world_ranking', 100),
                    player.get('avg_score', 72.0),
                    player.get('driving_distance', 290.0),
                    player.get('driving_accuracy', 0.65),
                    player.get('greens_in_regulation', 0.65),
                    player.get('putting_average', 1.8),
                    player.get('recent_form', 0.5),
                    player.get('course_history_avg', 72.0),
                    weather_data.get('difficulty_factor', 1.0) if weather_data else 1.0
                ]
                features.append(feature_row)
            
            return np.array(features)
            
        except Exception as e:
            logging.error(f"Error preparing features: {e}")
            return np.array([])

    def train_models(self, training_data):
        """Train both score prediction and win probability models"""
        try:
            if len(training_data) == 0:
                logging.warning("No training data available")
                return False
            
            df = pd.DataFrame(training_data)
            
            # Prepare features
            X = df[self.feature_columns].fillna(df[self.feature_columns].mean())
            
            # Score prediction model
            y_score = df['actual_score'].fillna(72.0)
            X_train, X_test, y_train, y_test = train_test_split(X, y_score, test_size=0.2, random_state=42)
            
            # Scale features
            X_train_scaled = self.scaler.fit_transform(X_train)
            X_test_scaled = self.scaler.transform(X_test)
            
            # Train score model
            self.score_model = RandomForestRegressor(n_estimators=100, random_state=42)
            self.score_model.fit(X_train_scaled, y_train)
            
            # Evaluate score model
            score_pred = self.score_model.predict(X_test_scaled)
            score_mse = mean_squared_error(y_test, score_pred)
            logging.info(f"Score prediction MSE: {score_mse}")
            
            # Win probability model
            y_win = (df['finish_position'] <= 1).astype(int)
            self.win_model = GradientBoostingClassifier(n_estimators=100, random_state=42)
            self.win_model.fit(X_train_scaled, y_win[X_train.index])
            
            # Evaluate win model
            win_pred = self.win_model.predict(X_test_scaled)
            win_accuracy = accuracy_score(y_win[X_test.index], win_pred)
            logging.info(f"Win prediction accuracy: {win_accuracy}")
            
            # Save models
            self.save_models()
            
            return True
            
        except Exception as e:
            logging.error(f"Error training models: {e}")
            return False

    def predict_scores(self, player_data, tournament_data=None, weather_data=None):
        """Predict scores and win probabilities for players"""
        try:
            if self.score_model is None:
                self.load_models()
            
            features = self.prepare_features(player_data, tournament_data, weather_data)
            
            if len(features) == 0:
                return {'success': False, 'error': 'No valid features prepared'}
            
            # Scale features
            features_scaled = self.scaler.transform(features)
            
            # Make predictions
            predicted_scores = self.score_model.predict(features_scaled) if self.score_model else [72.0] * len(features)
            win_probabilities = self.win_model.predict_proba(features_scaled)[:, 1] if self.win_model else [0.1] * len(features)
            
            # Combine results
            predictions = []
            for i, player in enumerate(player_data):
                prediction = {
                    'player_name': player.get('name', 'Unknown'),
                    'predicted_score': round(float(predicted_scores[i]), 2),
                    'win_probability': round(float(win_probabilities[i]), 4),
                    'confidence': self.calculate_confidence(features_scaled[i]),
                    'ranking': player.get('world_ranking', 100)
                }
                predictions.append(prediction)
            
            # Sort by win probability
            predictions.sort(key=lambda x: x['win_probability'], reverse=True)
            
            return {
                'success': True,
                'predictions': predictions,
                'model_version': 'v1.0',
                'generated_at': datetime.now().isoformat()
            }
            
        except Exception as e:
            logging.error(f"Error making predictions: {e}")
            return {'success': False, 'error': str(e)}

    def calculate_confidence(self, features):
        """Calculate confidence score based on feature quality"""
        try:
            # Simple confidence calculation based on feature completeness
            non_null_features = np.sum(~np.isnan(features))
            total_features = len(features)
            return round(non_null_features / total_features, 2)
        except:
            return 0.5

    def save_models(self):
        """Save trained models to disk"""
        try:
            if self.score_model:
                joblib.dump(self.score_model, os.path.join(MODEL_DIR, 'score_model.pkl'))
            if self.win_model:
                joblib.dump(self.win_model, os.path.join(MODEL_DIR, 'win_model.pkl'))
            joblib.dump(self.scaler, os.path.join(MODEL_DIR, 'scaler.pkl'))
            logging.info("Models saved successfully")
        except Exception as e:
            logging.error(f"Error saving models: {e}")

    def load_models(self):
        """Load trained models from disk"""
        try:
            score_path = os.path.join(MODEL_DIR, 'score_model.pkl')
            win_path = os.path.join(MODEL_DIR, 'win_model.pkl')
            scaler_path = os.path.join(MODEL_DIR, 'scaler.pkl')
            
            if os.path.exists(score_path):
                self.score_model = joblib.load(score_path)
            if os.path.exists(win_path):
                self.win_model = joblib.load(win_path)
            if os.path.exists(scaler_path):
                self.scaler = joblib.load(scaler_path)
                
            logging.info("Models loaded successfully")
            return True
        except Exception as e:
            logging.error(f"Error loading models: {e}")
            return False

# Global model instance
model = PGAPredictionModel()

def predict_scores(data):
    """Main prediction function called by the API"""
    try:
        tournament_data = data.get('tournament')
        weather_data = data.get('weather')
        
        # Get current player data
        player_response = get_player_stats()
        if not player_response.get('success'):
            return {'success': False, 'error': 'Unable to fetch player data'}
        
        player_data = player_response.get('players', [])
        
        # Make predictions
        predictions = model.predict_scores(player_data, tournament_data, weather_data)
        
        return predictions
        
    except Exception as e:
        logging.error(f"Error in predict_scores: {e}")
        return {'success': False, 'error': str(e)}

def train_model():
    """Train model with latest data - called by scheduler"""
    try:
        logging.info("Starting scheduled model training")
        
        # This would typically fetch historical tournament results
        # For now, we'll create synthetic training data based on available player stats
        player_response = get_player_stats()
        if player_response.get('success'):
            # Generate synthetic training data
            training_data = generate_synthetic_training_data(player_response.get('players', []))
            
            if model.train_models(training_data):
                logging.info("Model training completed successfully")
            else:
                logging.error("Model training failed")
        else:
            logging.error("Could not fetch player data for training")
            
    except Exception as e:
        logging.error(f"Error in scheduled model training: {e}")

def generate_synthetic_training_data(players):
    """Generate synthetic training data for model training"""
    try:
        training_data = []
        
        for player in players[:100]:  # Use top 100 players
            # Generate multiple synthetic tournament results per player
            for _ in range(10):  # 10 tournaments per player
                record = {
                    'world_ranking': player.get('world_ranking', 100),
                    'avg_score': player.get('avg_score', 72.0),
                    'driving_distance': player.get('driving_distance', 290.0),
                    'driving_accuracy': player.get('driving_accuracy', 0.65),
                    'greens_in_regulation': player.get('greens_in_regulation', 0.65),
                    'putting_average': player.get('putting_average', 1.8),
                    'recent_form': np.random.uniform(0, 1),
                    'course_history_avg': np.random.normal(72, 2),
                    'weather_factor': np.random.uniform(0.8, 1.2),
                    'actual_score': np.random.normal(72, 3),
                    'finish_position': np.random.randint(1, 150)
                }
                training_data.append(record)
        
        return training_data
        
    except Exception as e:
        logging.error(f"Error generating training data: {e}")
        return []
