import requests
import os
import logging
import numpy as np
from datetime import datetime
from statistics import mean

# Odds API configuration
ODDS_API_KEY = os.getenv('ODDS_API_KEY', 'demo_key')
ODDS_BASE_URL = "https://api.the-odds-api.com/v4"

def analyze_odds(bets_data):
    """Analyze betting odds and calculate expected value"""
    try:
        analysis_results = []
        
        for bet in bets_data.get('bets', []):
            bet_analysis = analyze_single_bet(bet)
            analysis_results.append(bet_analysis)
        
        # Calculate portfolio metrics
        portfolio_metrics = calculate_portfolio_metrics(analysis_results)
        
        return {
            'success': True,
            'bet_analyses': analysis_results,
            'portfolio_metrics': portfolio_metrics,
            'recommendations': generate_betting_recommendations(analysis_results),
            'analyzed_at': datetime.now().isoformat()
        }
        
    except Exception as e:
        logging.error(f"Error analyzing odds: {e}")
        return {'success': False, 'error': str(e)}

def analyze_single_bet(bet):
    """Analyze a single bet for value and risk"""
    try:
        player_name = bet.get('player_name', '')
        bet_type = bet.get('bet_type', 'win')
        odds = float(bet.get('odds', 1.0))
        stake = float(bet.get('stake', 0))
        
        # Get current market odds
        market_odds = get_market_odds(player_name, bet_type)
        
        # Calculate implied probability
        implied_prob = 1 / odds if odds > 0 else 0
        
        # Get our model's probability estimate
        model_prob = get_model_probability(player_name, bet_type)
        
        # Calculate expected value
        expected_value = calculate_expected_value(odds, model_prob, stake)
        
        # Calculate Kelly criterion suggested bet size
        kelly_fraction = calculate_kelly_criterion(odds, model_prob)
        
        # Risk assessment
        risk_score = assess_bet_risk(bet, market_odds, model_prob)
        
        return {
            'player_name': player_name,
            'bet_type': bet_type,
            'odds': odds,
            'stake': stake,
            'implied_probability': round(implied_prob, 4),
            'model_probability': round(model_prob, 4),
            'expected_value': round(expected_value, 2),
            'kelly_fraction': round(kelly_fraction, 4),
            'risk_score': risk_score,
            'market_comparison': compare_to_market(odds, market_odds),
            'recommendation': generate_bet_recommendation(expected_value, kelly_fraction, risk_score)
        }
        
    except Exception as e:
        logging.error(f"Error analyzing single bet: {e}")
        return {
            'error': str(e),
            'player_name': bet.get('player_name', 'Unknown'),
            'recommendation': 'AVOID - Analysis failed'
        }

def get_market_odds(player_name, bet_type):
    """Fetch current market odds for comparison"""
    try:
        url = f"{ODDS_BASE_URL}/sports/golf_pga/odds"
        params = {
            'api_key': ODDS_API_KEY,
            'regions': 'us',
            'markets': 'h2h,outrights',
            'oddsFormat': 'decimal'
        }
        
        response = requests.get(url, params=params, timeout=10)
        
        if response.status_code == 200:
            odds_data = response.json()
            
            # Parse odds for the specific player and bet type
            market_odds = extract_player_odds(odds_data, player_name, bet_type)
            return market_odds
        else:
            logging.warning(f"Odds API returned status {response.status_code}")
            return None
            
    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching market odds: {e}")
        return None
    except Exception as e:
        logging.error(f"Unexpected error fetching odds: {e}")
        return None

def extract_player_odds(odds_data, player_name, bet_type):
    """Extract odds for specific player from API response"""
    try:
        # This would parse the actual odds API response
        # For now, return a placeholder structure
        return {
            'best_odds': 5.0,
            'avg_odds': 4.5,
            'bookmaker_count': 3,
            'last_updated': datetime.now().isoformat()
        }
    except Exception as e:
        logging.error(f"Error extracting player odds: {e}")
        return None

def get_model_probability(player_name, bet_type):
    """Get probability estimate from our ML model"""
    try:
        # This would integrate with the ML model predictions
        # For now, return a reasonable estimate based on bet type
        if bet_type == 'win':
            return 0.02  # 2% chance to win tournament
        elif bet_type == 'top_5':
            return 0.15  # 15% chance for top 5
        elif bet_type == 'top_10':
            return 0.25  # 25% chance for top 10
        elif bet_type == 'make_cut':
            return 0.75  # 75% chance to make cut
        else:
            return 0.1   # Default 10%
            
    except Exception as e:
        logging.error(f"Error getting model probability: {e}")
        return 0.1

def calculate_expected_value(odds, model_prob, stake):
    """Calculate expected value of a bet"""
    try:
        win_amount = (odds - 1) * stake
        loss_amount = stake
        
        expected_value = (model_prob * win_amount) - ((1 - model_prob) * loss_amount)
        return expected_value
        
    except Exception as e:
        logging.error(f"Error calculating expected value: {e}")
        return 0

def calculate_kelly_criterion(odds, model_prob):
    """Calculate optimal bet size using Kelly Criterion"""
    try:
        if model_prob <= 0 or odds <= 1:
            return 0
        
        # Kelly formula: f = (bp - q) / b
        # where b = odds - 1, p = model probability, q = 1 - p
        b = odds - 1
        p = model_prob
        q = 1 - p
        
        kelly_fraction = (b * p - q) / b
        
        # Cap at 25% to manage risk
        return min(max(kelly_fraction, 0), 0.25)
        
    except Exception as e:
        logging.error(f"Error calculating Kelly criterion: {e}")
        return 0

def assess_bet_risk(bet, market_odds, model_prob):
    """Assess the risk level of a bet"""
    try:
        risk_factors = []
        
        # Volatility risk
        if bet.get('bet_type') == 'win':
            risk_factors.append(0.8)  # High risk
        elif bet.get('bet_type') in ['top_5', 'top_10']:
            risk_factors.append(0.5)  # Medium risk
        else:
            risk_factors.append(0.3)  # Lower risk
        
        # Model confidence risk
        confidence_risk = 1 - model_prob if model_prob < 0.5 else 0.3
        risk_factors.append(confidence_risk)
        
        # Market efficiency risk
        if market_odds and market_odds.get('bookmaker_count', 0) < 3:
            risk_factors.append(0.4)  # Low liquidity risk
        
        # Calculate overall risk score (0-1, higher = riskier)
        overall_risk = mean(risk_factors)
        
        if overall_risk < 0.3:
            return 'LOW'
        elif overall_risk < 0.6:
            return 'MEDIUM'
        else:
            return 'HIGH'
            
    except Exception as e:
        logging.error(f"Error assessing bet risk: {e}")
        return 'HIGH'

def compare_to_market(our_odds, market_odds):
    """Compare our odds to market odds"""
    try:
        if not market_odds:
            return {'status': 'NO_MARKET_DATA'}
        
        market_best = market_odds.get('best_odds', our_odds)
        market_avg = market_odds.get('avg_odds', our_odds)
        
        return {
            'our_odds': our_odds,
            'market_best': market_best,
            'market_avg': market_avg,
            'value_vs_best': round(((our_odds - market_best) / market_best) * 100, 2),
            'value_vs_avg': round(((our_odds - market_avg) / market_avg) * 100, 2),
            'is_value_bet': our_odds > market_avg
        }
        
    except Exception as e:
        logging.error(f"Error comparing to market: {e}")
        return {'status': 'COMPARISON_ERROR'}

def generate_bet_recommendation(expected_value, kelly_fraction, risk_score):
    """Generate betting recommendation based on analysis"""
    try:
        if expected_value > 0 and kelly_fraction > 0.02:
            if risk_score == 'LOW':
                return 'STRONG BUY'
            elif risk_score == 'MEDIUM':
                return 'BUY'
            else:
                return 'CONSIDER'
        elif expected_value > 0:
            return 'WEAK BUY'
        elif expected_value > -5:
            return 'NEUTRAL'
        else:
            return 'AVOID'
            
    except Exception as e:
        logging.error(f"Error generating recommendation: {e}")
        return 'AVOID'

def calculate_portfolio_metrics(bet_analyses):
    """Calculate overall portfolio metrics"""
    try:
        total_stakes = sum(bet.get('stake', 0) for bet in bet_analyses)
        total_expected_value = sum(bet.get('expected_value', 0) for bet in bet_analyses)
        
        risk_distribution = {
            'LOW': len([b for b in bet_analyses if b.get('risk_score') == 'LOW']),
            'MEDIUM': len([b for b in bet_analyses if b.get('risk_score') == 'MEDIUM']),
            'HIGH': len([b for b in bet_analyses if b.get('risk_score') == 'HIGH'])
        }
        
        return {
            'total_stakes': round(total_stakes, 2),
            'total_expected_value': round(total_expected_value, 2),
            'expected_roi': round((total_expected_value / total_stakes) * 100, 2) if total_stakes > 0 else 0,
            'number_of_bets': len(bet_analyses),
            'risk_distribution': risk_distribution,
            'value_bets': len([b for b in bet_analyses if b.get('expected_value', 0) > 0])
        }
        
    except Exception as e:
        logging.error(f"Error calculating portfolio metrics: {e}")
        return {}

def generate_betting_recommendations(analyses):
    """Generate overall betting recommendations"""
    try:
        strong_buys = [b for b in analyses if b.get('recommendation') == 'STRONG BUY']
        buys = [b for b in analyses if b.get('recommendation') in ['BUY', 'STRONG BUY']]
        avoids = [b for b in analyses if b.get('recommendation') == 'AVOID']
        
        recommendations = []
        
        if strong_buys:
            recommendations.append({
                'type': 'PRIORITY_BETS',
                'message': f"Focus on {len(strong_buys)} high-value, low-risk opportunities",
                'bets': [b['player_name'] for b in strong_buys[:3]]
            })
        
        if len(buys) > 5:
            recommendations.append({
                'type': 'DIVERSIFICATION',
                'message': "Consider reducing bet count to focus on highest-value opportunities",
                'suggestion': 'Limit to top 3-5 bets'
            })
        
        if len(avoids) > 0:
            recommendations.append({
                'type': 'RISK_WARNING',
                'message': f"Avoid {len(avoids)} negative expected value bets",
                'bets': [b['player_name'] for b in avoids]
            })
        
        return recommendations
        
    except Exception as e:
        logging.error(f"Error generating recommendations: {e}")
        return []
