import os
import logging
import asyncio
from datetime import datetime, timedelta
from telegram import Bot, Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
from telegram.error import TelegramError
import threading

# Import our services
from .pga_api import get_tournament_data, get_player_stats
from .ml_models import predict_scores
from .weather_service import get_weather_impact
from .chatgpt_service import analyze_tournament_preview

# Telegram Bot configuration
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', 'demo_token')
TELEGRAM_ADMIN_CHAT_ID = os.getenv('TELEGRAM_ADMIN_CHAT_ID', '')

# Global bot instance
bot_application = None
bot_instance = None

class TelegramBotService:
    def __init__(self):
        self.application = None
        self.bot = None
        self.is_running = False
        
    async def initialize_bot(self):
        """Initialize the Telegram bot"""
        try:
            if TELEGRAM_BOT_TOKEN == 'demo_token':
                logging.warning("Telegram bot token not configured - bot features disabled")
                return False
            
            # Create application
            self.application = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
            self.bot = self.application.bot
            
            # Add command handlers
            self.application.add_handler(CommandHandler("start", self.start_command))
            self.application.add_handler(CommandHandler("help", self.help_command))
            self.application.add_handler(CommandHandler("picks", self.picks_command))
            self.application.add_handler(CommandHandler("tournament", self.tournament_command))
            self.application.add_handler(CommandHandler("weather", self.weather_command))
            self.application.add_handler(CommandHandler("predictions", self.predictions_command))
            self.application.add_handler(CommandHandler("subscribe", self.subscribe_command))
            self.application.add_handler(CommandHandler("unsubscribe", self.unsubscribe_command))
            
            # Add message handler for general queries
            self.application.add_handler(
                MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message)
            )
            
            logging.info("Telegram bot initialized successfully")
            return True
            
        except Exception as e:
            logging.error(f"Error initializing Telegram bot: {e}")
            return False
    
    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command"""
        welcome_message = """
🏌️ Welcome to PGA Betting AI Bot!

I provide AI-powered golf betting recommendations and analysis.

Available commands:
/picks - Get today's betting picks
/tournament - Current tournament info
/weather - Weather impact analysis
/predictions - Latest AI predictions
/subscribe - Get daily picks
/unsubscribe - Stop daily picks
/help - Show this help message

Let's make some smart bets! 🎯
        """
        
        await update.message.reply_text(welcome_message)
        
        # Log new user
        chat_id = update.effective_chat.id
        username = update.effective_user.username or "Unknown"
        logging.info(f"New Telegram user started bot: {username} (ID: {chat_id})")
    
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /help command"""
        help_message = """
🏌️ PGA Betting AI Bot Commands:

📊 **Analysis Commands:**
/picks - Get today's top betting recommendations
/tournament - Current tournament information
/weather - Weather impact on gameplay
/predictions - Latest AI model predictions

⚙️ **Settings:**
/subscribe - Receive daily picks at 8 AM
/unsubscribe - Stop daily notifications

💬 **General:**
Send me any golf betting question and I'll analyze it for you!

🎯 **Tips:**
- All recommendations use advanced ML models
- Weather data impacts player selection
- Historical performance analysis included
        """
        
        await update.message.reply_text(help_message)
    
    async def picks_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /picks command - provide betting picks"""
        try:
            await update.message.reply_text("🔍 Analyzing current tournament data...")
            
            # Get tournament data
            tournament_data = get_tournament_data()
            
            if not tournament_data.get('success'):
                await update.message.reply_text(
                    "❌ Sorry, tournament data is currently unavailable. Please try again later."
                )
                return
            
            # Get predictions
            prediction_request = {
                'tournament': tournament_data.get('tournaments', [{}])[0] if tournament_data.get('tournaments') else {},
                'weather': get_weather_impact()
            }
            
            predictions = predict_scores(prediction_request)
            
            if not predictions.get('success'):
                await update.message.reply_text(
                    "❌ Unable to generate predictions at this time. Please try again later."
                )
                return
            
            # Format picks message
            picks_message = self.format_picks_message(predictions, tournament_data)
            await update.message.reply_text(picks_message, parse_mode='Markdown')
            
        except Exception as e:
            logging.error(f"Error in picks command: {e}")
            await update.message.reply_text(
                "❌ Error generating picks. Please try again later."
            )
    
    async def tournament_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /tournament command"""
        try:
            tournament_data = get_tournament_data()
            
            if not tournament_data.get('success'):
                await update.message.reply_text(
                    "❌ Tournament data unavailable. Please try again later."
                )
                return
            
            tournaments = tournament_data.get('tournaments', [])
            if not tournaments:
                await update.message.reply_text(
                    "📅 No current tournaments found."
                )
                return
            
            # Format tournament info
            tournament_message = self.format_tournament_message(tournaments[0])
            await update.message.reply_text(tournament_message, parse_mode='Markdown')
            
        except Exception as e:
            logging.error(f"Error in tournament command: {e}")
            await update.message.reply_text(
                "❌ Error fetching tournament data."
            )
    
    async def weather_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /weather command"""
        try:
            weather_data = get_weather_impact()
            
            if not weather_data.get('success'):
                await update.message.reply_text(
                    "❌ Weather data unavailable. Please try again later."
                )
                return
            
            weather_message = self.format_weather_message(weather_data)
            await update.message.reply_text(weather_message, parse_mode='Markdown')
            
        except Exception as e:
            logging.error(f"Error in weather command: {e}")
            await update.message.reply_text(
                "❌ Error fetching weather data."
            )
    
    async def predictions_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /predictions command"""
        try:
            # Get latest predictions
            prediction_request = {
                'tournament': {},
                'weather': get_weather_impact()
            }
            
            predictions = predict_scores(prediction_request)
            
            if not predictions.get('success'):
                await update.message.reply_text(
                    "❌ Unable to generate predictions at this time."
                )
                return
            
            predictions_message = self.format_predictions_message(predictions)
            await update.message.reply_text(predictions_message, parse_mode='Markdown')
            
        except Exception as e:
            logging.error(f"Error in predictions command: {e}")
            await update.message.reply_text(
                "❌ Error generating predictions."
            )
    
    async def subscribe_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /subscribe command"""
        chat_id = update.effective_chat.id
        
        # Store subscription (in production, this would go to a database)
        # For now, just acknowledge
        await update.message.reply_text(
            "✅ You're subscribed to daily picks!\n\n"
            "🕰️ You'll receive AI-powered betting recommendations every day at 8:00 AM.\n\n"
            "Use /unsubscribe to stop notifications anytime."
        )
        
        logging.info(f"User subscribed to daily picks: {chat_id}")
    
    async def unsubscribe_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /unsubscribe command"""
        chat_id = update.effective_chat.id
        
        await update.message.reply_text(
            "❌ You've been unsubscribed from daily picks.\n\n"
            "Use /subscribe to re-enable notifications anytime."
        )
        
        logging.info(f"User unsubscribed from daily picks: {chat_id}")
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle general text messages"""
        try:
            user_message = update.message.text
            
            # Simple keyword-based responses
            if any(word in user_message.lower() for word in ['pick', 'recommend', 'bet']):
                await self.picks_command(update, context)
            elif any(word in user_message.lower() for word in ['weather', 'rain', 'wind']):
                await self.weather_command(update, context)
            elif any(word in user_message.lower() for word in ['tournament', 'event']):
                await self.tournament_command(update, context)
            else:
                # Provide general help
                await update.message.reply_text(
                    "🤔 I'm not sure how to help with that.\n\n"
                    "Try using one of these commands:\n"
                    "/picks - Get betting recommendations\n"
                    "/tournament - Tournament info\n"
                    "/weather - Weather analysis\n"
                    "/help - Full command list"
                )
                
        except Exception as e:
            logging.error(f"Error handling message: {e}")
            await update.message.reply_text(
                "❌ Sorry, I encountered an error. Please try again."
            )
    
    def format_picks_message(self, predictions, tournament_data):
        """Format betting picks message"""
        try:
            picks = predictions.get('predictions', [])[:5]  # Top 5 picks
            tournament = tournament_data.get('tournaments', [{}])[0]
            
            message = f"🏌️ **Today's Top Betting Picks**\n\n"
            
            if tournament.get('name'):
                message += f"🏆 **{tournament['name']}**\n"
            if tournament.get('course'):
                message += f"📍 {tournament['course']}\n\n"
            
            message += "🎯 **AI Recommendations:**\n\n"
            
            for i, pick in enumerate(picks, 1):
                player_name = pick.get('player_name', 'Unknown')
                win_prob = pick.get('win_probability', 0) * 100
                confidence = pick.get('confidence', 0) * 100
                
                message += f"**{i}. {player_name}**\n"
                message += f"   🎲 Win Probability: {win_prob:.1f}%\n"
                message += f"   🎯 Confidence: {confidence:.0f}%\n\n"
            
            message += "⚠️ *Remember: Bet responsibly and within your limits*"
            
            return message
            
        except Exception as e:
            logging.error(f"Error formatting picks message: {e}")
            return "❌ Error formatting betting picks."
    
    def format_tournament_message(self, tournament):
        """Format tournament information message"""
        try:
            message = "🏌️ **Current Tournament**\n\n"
            
            if tournament.get('name'):
                message += f"🏆 **{tournament['name']}**\n"
            if tournament.get('course'):
                message += f"📍 Course: {tournament['course']}\n"
            if tournament.get('date'):
                message += f"📅 Date: {tournament['date']}\n"
            if tournament.get('purse'):
                message += f"💰 Purse: ${tournament['purse']:,}\n"
            
            message += f"\n📊 Last updated: {datetime.now().strftime('%H:%M %Z')}"
            
            return message
            
        except Exception as e:
            logging.error(f"Error formatting tournament message: {e}")
            return "❌ Error formatting tournament information."
    
    def format_weather_message(self, weather_data):
        """Format weather impact message"""
        try:
            message = "🌤️ **Weather Impact Analysis**\n\n"
            
            overall = weather_data.get('overall_assessment', {})
            impacts = weather_data.get('weather_impacts', [])
            
            if overall.get('overall_rating'):
                rating = overall['overall_rating']
                message += f"🎯 **Overall Conditions:** {rating}\n"
            
            if overall.get('average_difficulty'):
                difficulty = overall['average_difficulty']
                message += f"📊 **Difficulty Factor:** {difficulty:.1f}/1.0\n\n"
            
            if impacts:
                message += "📍 **Key Locations:**\n"
                for impact in impacts[:3]:  # Top 3 locations
                    location = impact.get('location', 'Unknown')
                    factor = impact.get('difficulty_factor', 0)
                    message += f"   • {location}: {factor:.1f}/1.0\n"
            
            recommendations = overall.get('global_recommendations', [])
            if recommendations:
                message += "\n💡 **Recommendations:**\n"
                for rec in recommendations[:2]:  # Top 2 recommendations
                    message += f"   • {rec}\n"
            
            return message
            
        except Exception as e:
            logging.error(f"Error formatting weather message: {e}")
            return "❌ Error formatting weather information."
    
    def format_predictions_message(self, predictions):
        """Format AI predictions message"""
        try:
            preds = predictions.get('predictions', [])[:8]  # Top 8 predictions
            
            message = "🤖 **AI Model Predictions**\n\n"
            message += f"📊 Model: {predictions.get('model_version', 'v1.0')}\n"
            message += f"🕒 Generated: {datetime.now().strftime('%H:%M')}\n\n"
            
            message += "🏆 **Top Contenders:**\n"
            
            for i, pred in enumerate(preds, 1):
                player_name = pred.get('player_name', 'Unknown')
                score = pred.get('predicted_score', 0)
                win_prob = pred.get('win_probability', 0) * 100
                
                message += f"{i}. **{player_name}**\n"
                message += f"   Score: {score:.1f} | Win: {win_prob:.1f}%\n"
            
            return message
            
        except Exception as e:
            logging.error(f"Error formatting predictions message: {e}")
            return "❌ Error formatting predictions."

# Global service instance
telegram_service = TelegramBotService()

def start_telegram_bot():
    """Start the Telegram bot in a separate thread"""
    try:
        if TELEGRAM_BOT_TOKEN == 'demo_token':
            logging.info("Telegram bot not configured - skipping startup")
            return
        
        # Run bot initialization in a new thread
        def run_bot():
            try:
                # Create new event loop for this thread
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                async def start_bot():
                    if await telegram_service.initialize_bot():
                        logging.info("Starting Telegram bot polling...")
                        await telegram_service.application.run_polling()
                    else:
                        logging.error("Failed to initialize Telegram bot")
                
                loop.run_until_complete(start_bot())
                
            except Exception as e:
                logging.error(f"Error running Telegram bot: {e}")
        
        # Start bot in background thread
        bot_thread = threading.Thread(target=run_bot, daemon=True)
        bot_thread.start()
        
        logging.info("Telegram bot thread started")
        
    except Exception as e:
        logging.error(f"Error starting Telegram bot: {e}")

async def send_daily_picks():
    """Send daily picks to subscribers"""
    try:
        if not telegram_service.bot or TELEGRAM_BOT_TOKEN == 'demo_token':
            logging.info("Telegram bot not available for daily picks")
            return
        
        # Get today's picks
        tournament_data = get_tournament_data()
        prediction_request = {
            'tournament': tournament_data.get('tournaments', [{}])[0] if tournament_data.get('tournaments') else {},
            'weather': get_weather_impact()
        }
        
        predictions = predict_scores(prediction_request)
        
        if not predictions.get('success'):
            logging.error("Failed to generate daily picks")
            return
        
        # Format message
        picks_message = telegram_service.format_picks_message(predictions, tournament_data)
        daily_message = f"🌅 **Good Morning! Daily Picks Ready**\n\n{picks_message}"
        
        # Send to admin chat (in production, send to all subscribers)
        if TELEGRAM_ADMIN_CHAT_ID:
            try:
                await telegram_service.bot.send_message(
                    chat_id=TELEGRAM_ADMIN_CHAT_ID,
                    text=daily_message,
                    parse_mode='Markdown'
                )
                logging.info("Daily picks sent successfully")
            except TelegramError as e:
                logging.error(f"Error sending daily picks: {e}")
        
    except Exception as e:
        logging.error(f"Error in send_daily_picks: {e}")

def send_daily_picks_sync():
    """Synchronous wrapper for send_daily_picks (for scheduler)"""
    try:
        # Run async function in a new event loop
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(send_daily_picks())
        loop.close()
    except Exception as e:
        logging.error(f"Error in send_daily_picks_sync: {e}")

# Export the sync version for scheduler
send_daily_picks = send_daily_picks_sync

