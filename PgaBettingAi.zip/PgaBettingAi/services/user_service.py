from werkzeug.security import generate_password_hash, check_password_hash
import os
import logging
from datetime import datetime
from app import db
from models import User, Bet, Prediction

def create_user(user_data):
    """Create a new user account"""
    try:
        username = user_data.get('username', '').strip()
        email = user_data.get('email', '').strip()
        password = user_data.get('password', '')
        telegram_chat_id = user_data.get('telegram_chat_id', '').strip()
        
        # Validation
        if not username or len(username) < 3:
            return {'success': False, 'error': 'Username must be at least 3 characters long'}
        
        if not email or '@' not in email:
            return {'success': False, 'error': 'Valid email address is required'}
        
        if not password or len(password) < 6:
            return {'success': False, 'error': 'Password must be at least 6 characters long'}
        
        # Check if user already exists
        existing_user = User.query.filter(
            (User.username == username) | (User.email == email)
        ).first()
        
        if existing_user:
            if existing_user.username == username:
                return {'success': False, 'error': 'Username already exists'}
            else:
                return {'success': False, 'error': 'Email already registered'}
        
        # Create new user
        password_hash = generate_password_hash(password)
        
        new_user = User(
            username=username,
            email=email,
            password_hash=password_hash,
            telegram_chat_id=telegram_chat_id or None,
            created_at=datetime.utcnow(),
            is_active=True
        )
        
        db.session.add(new_user)
        db.session.commit()
        
        logging.info(f"New user created: {username}")
        
        return {
            'success': True,
            'message': 'User account created successfully',
            'user_id': new_user.id,
            'username': new_user.username
        }
        
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error creating user: {e}")
        return {'success': False, 'error': 'Failed to create user account'}

def authenticate_user(login_data):
    """Authenticate user login"""
    try:
        identifier = login_data.get('username', '').strip()  # Can be username or email
        password = login_data.get('password', '')
        
        if not identifier or not password:
            return {'success': False, 'error': 'Username/email and password are required'}
        
        # Find user by username or email
        user = User.query.filter(
            (User.username == identifier) | (User.email == identifier)
        ).first()
        
        if not user:
            return {'success': False, 'error': 'Invalid username/email or password'}
        
        if not user.is_active:
            return {'success': False, 'error': 'Account is deactivated'}
        
        # Check password
        if not check_password_hash(user.password_hash, password):
            return {'success': False, 'error': 'Invalid username/email or password'}
        
        logging.info(f"User authenticated: {user.username}")
        
        return {
            'success': True,
            'message': 'Authentication successful',
            'user_id': user.id,
            'username': user.username,
            'email': user.email
        }
        
    except Exception as e:
        logging.error(f"Error authenticating user: {e}")
        return {'success': False, 'error': 'Authentication failed'}

def get_user_profile(user_id):
    """Get user profile and statistics"""
    try:
        user = User.query.get(user_id)
        if not user:
            return {'success': False, 'error': 'User not found'}
        
        # Get user statistics
        stats = calculate_user_stats(user_id)
        
        # Get recent activity
        recent_bets = get_recent_bets(user_id, limit=5)
        recent_predictions = get_recent_predictions(user_id, limit=5)
        
        profile_data = {
            'success': True,
            'user_info': {
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'telegram_chat_id': user.telegram_chat_id,
                'member_since': user.created_at.isoformat() if user.created_at else None,
                'is_active': user.is_active
            },
            'statistics': stats,
            'recent_activity': {
                'recent_bets': recent_bets,
                'recent_predictions': recent_predictions
            }
        }
        
        return profile_data
        
    except Exception as e:
        logging.error(f"Error getting user profile: {e}")
        return {'success': False, 'error': 'Failed to retrieve user profile'}

def calculate_user_stats(user_id):
    """Calculate user betting and prediction statistics"""
    try:
        # Betting statistics
        total_bets = Bet.query.filter_by(user_id=user_id).count()
        pending_bets = Bet.query.filter_by(user_id=user_id, status='pending').count()
        won_bets = Bet.query.filter_by(user_id=user_id, status='won').count()
        lost_bets = Bet.query.filter_by(user_id=user_id, status='lost').count()
        
        # Calculate financial statistics
        total_staked = db.session.query(db.func.sum(Bet.stake)).filter_by(user_id=user_id).scalar() or 0
        total_winnings = db.session.query(db.func.sum(Bet.potential_payout)).filter(
            Bet.user_id == user_id, Bet.status == 'won'
        ).scalar() or 0
        
        # Prediction statistics
        total_predictions = Prediction.query.filter_by(user_id=user_id).count()
        
        # Calculate win rates
        win_rate = round((won_bets / total_bets) * 100, 1) if total_bets > 0 else 0
        roi = round(((total_winnings - total_staked) / total_staked) * 100, 1) if total_staked > 0 else 0
        
        return {
            'betting': {
                'total_bets': total_bets,
                'pending_bets': pending_bets,
                'won_bets': won_bets,
                'lost_bets': lost_bets,
                'win_rate': win_rate,
                'total_staked': round(total_staked, 2),
                'total_winnings': round(total_winnings, 2),
                'profit_loss': round(total_winnings - total_staked, 2),
                'roi': roi
            },
            'predictions': {
                'total_predictions': total_predictions,
                'avg_confidence': calculate_avg_confidence(user_id)
            }
        }
        
    except Exception as e:
        logging.error(f"Error calculating user stats: {e}")
        return {
            'betting': {'total_bets': 0, 'win_rate': 0, 'roi': 0},
            'predictions': {'total_predictions': 0}
        }

def calculate_avg_confidence(user_id):
    """Calculate average confidence score for user predictions"""
    try:
        avg_confidence = db.session.query(db.func.avg(Prediction.confidence_score)).filter_by(
            user_id=user_id
        ).scalar()
        
        return round(avg_confidence, 2) if avg_confidence else 0
        
    except Exception as e:
        logging.error(f"Error calculating average confidence: {e}")
        return 0

def get_recent_bets(user_id, limit=5):
    """Get user's recent bets"""
    try:
        recent_bets = Bet.query.filter_by(user_id=user_id).order_by(
            Bet.placed_at.desc()
        ).limit(limit).all()
        
        bets_data = []
        for bet in recent_bets:
            bet_data = {
                'id': bet.id,
                'player_name': bet.player_name,
                'bet_type': bet.bet_type,
                'odds': bet.odds,
                'stake': bet.stake,
                'potential_payout': bet.potential_payout,
                'status': bet.status,
                'placed_at': bet.placed_at.isoformat() if bet.placed_at else None,
                'settled_at': bet.settled_at.isoformat() if bet.settled_at else None
            }
            bets_data.append(bet_data)
        
        return bets_data
        
    except Exception as e:
        logging.error(f"Error getting recent bets: {e}")
        return []

def get_recent_predictions(user_id, limit=5):
    """Get user's recent predictions"""
    try:
        recent_predictions = Prediction.query.filter_by(user_id=user_id).order_by(
            Prediction.created_at.desc()
        ).limit(limit).all()
        
        predictions_data = []
        for prediction in recent_predictions:
            prediction_data = {
                'id': prediction.id,
                'player_id': prediction.player_id,
                'predicted_score': prediction.predicted_score,
                'win_probability': prediction.win_probability,
                'confidence_score': prediction.confidence_score,
                'prediction_type': prediction.prediction_type,
                'created_at': prediction.created_at.isoformat() if prediction.created_at else None,
                'model_version': prediction.model_version
            }
            predictions_data.append(prediction_data)
        
        return predictions_data
        
    except Exception as e:
        logging.error(f"Error getting recent predictions: {e}")
        return []

def update_user_profile(user_id, update_data):
    """Update user profile information"""
    try:
        user = User.query.get(user_id)
        if not user:
            return {'success': False, 'error': 'User not found'}
        
        # Update allowed fields
        if 'telegram_chat_id' in update_data:
            user.telegram_chat_id = update_data['telegram_chat_id'].strip() or None
        
        if 'email' in update_data:
            new_email = update_data['email'].strip()
            if '@' not in new_email:
                return {'success': False, 'error': 'Invalid email address'}
            
            # Check if email is already taken by another user
            existing = User.query.filter(User.email == new_email, User.id != user_id).first()
            if existing:
                return {'success': False, 'error': 'Email already in use'}
            
            user.email = new_email
        
        db.session.commit()
        
        return {
            'success': True,
            'message': 'Profile updated successfully'
        }
        
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error updating user profile: {e}")
        return {'success': False, 'error': 'Failed to update profile'}

def change_password(user_id, password_data):
    """Change user password"""
    try:
        user = User.query.get(user_id)
        if not user:
            return {'success': False, 'error': 'User not found'}
        
        current_password = password_data.get('current_password', '')
        new_password = password_data.get('new_password', '')
        
        # Verify current password
        if not check_password_hash(user.password_hash, current_password):
            return {'success': False, 'error': 'Current password is incorrect'}
        
        # Validate new password
        if len(new_password) < 6:
            return {'success': False, 'error': 'New password must be at least 6 characters long'}
        
        # Update password
        user.password_hash = generate_password_hash(new_password)
        db.session.commit()
        
        logging.info(f"Password changed for user: {user.username}")
        
        return {
            'success': True,
            'message': 'Password changed successfully'
        }
        
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error changing password: {e}")
        return {'success': False, 'error': 'Failed to change password'}

def deactivate_user(user_id):
    """Deactivate user account"""
    try:
        user = User.query.get(user_id)
        if not user:
            return {'success': False, 'error': 'User not found'}
        
        user.is_active = False
        db.session.commit()
        
        logging.info(f"User deactivated: {user.username}")
        
        return {
            'success': True,
            'message': 'Account deactivated successfully'
        }
        
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error deactivating user: {e}")
        return {'success': False, 'error': 'Failed to deactivate account'}
