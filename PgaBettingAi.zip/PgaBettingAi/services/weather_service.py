import requests
import os
import logging
from datetime import datetime, timedelta

# Weather API configuration
WEATHER_API_KEY = os.getenv('OPENWEATHER_API_KEY', 'demo_key')
WEATHER_BASE_URL = "http://api.openweathermap.org/data/2.5"

def get_weather_impact():
    """Get weather data and analyze impact on golf performance"""
    try:
        # Default golf courses - in production, this would be dynamic based on current tournaments
        golf_locations = [
            {'name': 'Augusta National', 'lat': 33.5030, 'lon': -82.0200},
            {'name': 'Pebble Beach', 'lat': 36.5674, 'lon': -121.9490},
            {'name': 'St Andrews', 'lat': 56.3398, 'lon': -2.7967}
        ]
        
        weather_impacts = []
        
        for location in golf_locations:
            weather_data = fetch_weather_data(location)
            if weather_data:
                impact_analysis = analyze_weather_impact(weather_data, location)
                weather_impacts.append(impact_analysis)
        
        return {
            'success': True,
            'weather_impacts': weather_impacts,
            'overall_assessment': calculate_overall_weather_impact(weather_impacts),
            'last_updated': datetime.now().isoformat()
        }
        
    except Exception as e:
        logging.error(f"Error getting weather impact: {e}")
        return get_fallback_weather_data()

def fetch_weather_data(location):
    """Fetch current and forecast weather data for a location"""
    try:
        # Current weather
        current_url = f"{WEATHER_BASE_URL}/weather"
        params = {
            'lat': location['lat'],
            'lon': location['lon'],
            'appid': WEATHER_API_KEY,
            'units': 'imperial'
        }
        
        current_response = requests.get(current_url, params=params, timeout=10)
        
        if current_response.status_code != 200:
            logging.warning(f"Weather API returned status {current_response.status_code}")
            return None
        
        current_data = current_response.json()
        
        # 5-day forecast
        forecast_url = f"{WEATHER_BASE_URL}/forecast"
        forecast_response = requests.get(forecast_url, params=params, timeout=10)
        
        forecast_data = {}
        if forecast_response.status_code == 200:
            forecast_data = forecast_response.json()
        
        return {
            'location': location,
            'current': current_data,
            'forecast': forecast_data
        }
        
    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching weather data for {location['name']}: {e}")
        return None
    except Exception as e:
        logging.error(f"Unexpected error fetching weather: {e}")
        return None

def analyze_weather_impact(weather_data, location):
    """Analyze how weather conditions will impact golf performance"""
    try:
        current = weather_data['current']
        forecast = weather_data.get('forecast', {})
        
        # Extract key weather metrics
        wind_speed = current.get('wind', {}).get('speed', 0)
        wind_direction = current.get('wind', {}).get('deg', 0)
        temperature = current.get('main', {}).get('temp', 70)
        humidity = current.get('main', {}).get('humidity', 50)
        pressure = current.get('main', {}).get('pressure', 1013)
        conditions = current.get('weather', [{}])[0].get('main', 'Clear')
        
        # Calculate impact scores (0-1 scale, higher = more difficult)
        impact_scores = {
            'wind_impact': calculate_wind_impact(wind_speed, wind_direction),
            'temperature_impact': calculate_temperature_impact(temperature),
            'humidity_impact': calculate_humidity_impact(humidity),
            'precipitation_impact': calculate_precipitation_impact(conditions),
            'overall_difficulty': 0
        }
        
        # Calculate overall difficulty
        impact_scores['overall_difficulty'] = calculate_overall_difficulty(impact_scores)
        
        # Generate playing conditions assessment
        conditions_assessment = assess_playing_conditions(impact_scores, current)
        
        # Forecast analysis
        forecast_analysis = analyze_forecast_trend(forecast)
        
        return {
            'location': location['name'],
            'current_conditions': {
                'temperature': temperature,
                'wind_speed': wind_speed,
                'wind_direction': wind_direction,
                'humidity': humidity,
                'conditions': conditions
            },
            'impact_scores': impact_scores,
            'conditions_assessment': conditions_assessment,
            'forecast_trend': forecast_analysis,
            'difficulty_factor': round(impact_scores['overall_difficulty'], 2),
            'recommendations': generate_weather_recommendations(impact_scores, conditions_assessment)
        }
        
    except Exception as e:
        logging.error(f"Error analyzing weather impact: {e}")
        return {
            'location': location.get('name', 'Unknown'),
            'error': str(e),
            'difficulty_factor': 1.0
        }

def calculate_wind_impact(wind_speed, wind_direction):
    """Calculate impact of wind on golf performance"""
    try:
        # Wind speed impact (mph)
        if wind_speed < 5:
            speed_impact = 0.1
        elif wind_speed < 10:
            speed_impact = 0.3
        elif wind_speed < 15:
            speed_impact = 0.5
        elif wind_speed < 20:
            speed_impact = 0.7
        else:
            speed_impact = 0.9
        
        # Wind direction doesn't significantly change difficulty in general
        # but could be course-specific
        direction_factor = 1.0
        
        return speed_impact * direction_factor
        
    except Exception:
        return 0.3  # Default moderate impact

def calculate_temperature_impact(temperature):
    """Calculate impact of temperature on golf performance"""
    try:
        # Optimal temperature range is 65-75°F
        if 65 <= temperature <= 75:
            return 0.1  # Ideal conditions
        elif 55 <= temperature < 65 or 75 < temperature <= 85:
            return 0.3  # Slightly challenging
        elif 45 <= temperature < 55 or 85 < temperature <= 95:
            return 0.5  # Moderately challenging
        else:
            return 0.7  # Very challenging
            
    except Exception:
        return 0.3

def calculate_humidity_impact(humidity):
    """Calculate impact of humidity on golf performance"""
    try:
        # High humidity affects ball flight and player comfort
        if humidity < 30:
            return 0.2  # Low humidity, minimal impact
        elif humidity < 60:
            return 0.1  # Comfortable range
        elif humidity < 80:
            return 0.3  # Noticeable impact
        else:
            return 0.5  # High impact
            
    except Exception:
        return 0.2

def calculate_precipitation_impact(conditions):
    """Calculate impact of precipitation on golf performance"""
    try:
        precipitation_conditions = {
            'Rain': 0.8,
            'Drizzle': 0.4,
            'Thunderstorm': 0.9,
            'Snow': 1.0,
            'Clear': 0.0,
            'Clouds': 0.1,
            'Mist': 0.3,
            'Fog': 0.4
        }
        
        return precipitation_conditions.get(conditions, 0.2)
        
    except Exception:
        return 0.2

def calculate_overall_difficulty(impact_scores):
    """Calculate overall weather difficulty factor"""
    try:
        weights = {
            'wind_impact': 0.4,
            'temperature_impact': 0.2,
            'humidity_impact': 0.1,
            'precipitation_impact': 0.3
        }
        
        overall = 0
        for factor, weight in weights.items():
            overall += impact_scores.get(factor, 0) * weight
        
        # Add base difficulty of 0.3 (normal conditions)
        return min(overall + 0.3, 1.0)
        
    except Exception:
        return 0.5

def assess_playing_conditions(impact_scores, current_weather):
    """Assess overall playing conditions"""
    try:
        difficulty = impact_scores['overall_difficulty']
        
        if difficulty < 0.4:
            condition_rating = 'EXCELLENT'
            description = 'Ideal conditions for low scoring'
        elif difficulty < 0.6:
            condition_rating = 'GOOD'
            description = 'Favorable conditions with minor challenges'
        elif difficulty < 0.8:
            condition_rating = 'CHALLENGING'
            description = 'Difficult conditions, expect higher scores'
        else:
            condition_rating = 'SEVERE'
            description = 'Extremely challenging conditions'
        
        return {
            'rating': condition_rating,
            'description': description,
            'key_factors': identify_key_weather_factors(impact_scores),
            'scoring_adjustment': calculate_scoring_adjustment(difficulty)
        }
        
    except Exception as e:
        logging.error(f"Error assessing playing conditions: {e}")
        return {
            'rating': 'UNKNOWN',
            'description': 'Unable to assess conditions',
            'scoring_adjustment': 0
        }

def identify_key_weather_factors(impact_scores):
    """Identify the most significant weather factors"""
    try:
        factors = []
        
        if impact_scores.get('wind_impact', 0) > 0.5:
            factors.append('High winds affecting ball flight')
        if impact_scores.get('precipitation_impact', 0) > 0.4:
            factors.append('Wet conditions affecting course play')
        if impact_scores.get('temperature_impact', 0) > 0.4:
            factors.append('Temperature affecting player performance')
        
        return factors if factors else ['Favorable weather conditions']
        
    except Exception:
        return ['Weather impact analysis unavailable']

def calculate_scoring_adjustment(difficulty):
    """Calculate expected scoring adjustment due to weather"""
    try:
        # Base score is 72, adjust based on difficulty
        base_adjustment = (difficulty - 0.5) * 4  # Range of -2 to +2 strokes
        return round(base_adjustment, 1)
        
    except Exception:
        return 0

def analyze_forecast_trend(forecast_data):
    """Analyze weather forecast trend"""
    try:
        if not forecast_data or 'list' not in forecast_data:
            return {'trend': 'NO_FORECAST', 'description': 'Forecast data unavailable'}
        
        # Analyze next 3 days
        forecast_items = forecast_data['list'][:24]  # Next 24 hours (3-hour intervals)
        
        wind_speeds = []
        temperatures = []
        conditions = []
        
        for item in forecast_items:
            wind_speeds.append(item.get('wind', {}).get('speed', 0))
            temperatures.append(item.get('main', {}).get('temp', 70))
            conditions.append(item.get('weather', [{}])[0].get('main', 'Clear'))
        
        # Determine trend
        if len(wind_speeds) > 1:
            wind_trend = 'INCREASING' if wind_speeds[-1] > wind_speeds[0] else 'DECREASING'
            temp_trend = 'WARMING' if temperatures[-1] > temperatures[0] else 'COOLING'
        else:
            wind_trend = 'STABLE'
            temp_trend = 'STABLE'
        
        return {
            'trend': f"Wind {wind_trend}, Temperature {temp_trend}",
            'avg_wind': round(sum(wind_speeds) / len(wind_speeds), 1),
            'avg_temp': round(sum(temperatures) / len(temperatures), 1),
            'conditions_forecast': most_common_condition(conditions)
        }
        
    except Exception as e:
        logging.error(f"Error analyzing forecast: {e}")
        return {'trend': 'ANALYSIS_ERROR', 'description': 'Unable to analyze forecast'}

def most_common_condition(conditions):
    """Find most common weather condition in forecast"""
    try:
        from collections import Counter
        condition_counts = Counter(conditions)
        return condition_counts.most_common(1)[0][0]
    except:
        return 'Variable'

def generate_weather_recommendations(impact_scores, conditions_assessment):
    """Generate weather-based recommendations"""
    try:
        recommendations = []
        
        if impact_scores.get('wind_impact', 0) > 0.5:
            recommendations.append("Favor players with strong wind management skills")
            recommendations.append("Consider players with accurate short games")
        
        if impact_scores.get('precipitation_impact', 0) > 0.4:
            recommendations.append("Look for players who perform well in wet conditions")
            recommendations.append("Expect longer approach shots due to reduced roll")
        
        if conditions_assessment.get('scoring_adjustment', 0) > 1:
            recommendations.append("Expect higher scoring - adjust predictions accordingly")
        elif conditions_assessment.get('scoring_adjustment', 0) < -1:
            recommendations.append("Ideal scoring conditions - expect lower scores")
        
        if not recommendations:
            recommendations.append("Weather conditions are favorable for normal play")
        
        return recommendations
        
    except Exception:
        return ["Weather analysis recommendations unavailable"]

def calculate_overall_weather_impact(weather_impacts):
    """Calculate overall weather impact across all locations"""
    try:
        if not weather_impacts:
            return get_fallback_overall_assessment()
        
        avg_difficulty = sum(w.get('difficulty_factor', 0.5) for w in weather_impacts) / len(weather_impacts)
        
        all_recommendations = []
        for impact in weather_impacts:
            all_recommendations.extend(impact.get('recommendations', []))
        
        # Remove duplicates while preserving order
        unique_recommendations = list(dict.fromkeys(all_recommendations))
        
        return {
            'average_difficulty': round(avg_difficulty, 2),
            'overall_rating': 'CHALLENGING' if avg_difficulty > 0.6 else 'FAVORABLE',
            'global_recommendations': unique_recommendations[:5],  # Top 5 recommendations
            'locations_analyzed': len(weather_impacts)
        }
        
    except Exception as e:
        logging.error(f"Error calculating overall weather impact: {e}")
        return get_fallback_overall_assessment()

def get_fallback_weather_data():
    """Provide fallback weather data when API is unavailable"""
    return {
        'success': False,
        'error': 'Weather API unavailable',
        'weather_impacts': [],
        'overall_assessment': get_fallback_overall_assessment(),
        'message': 'Weather data temporarily unavailable. Using default conditions.',
        'last_updated': datetime.now().isoformat()
    }

def get_fallback_overall_assessment():
    """Fallback overall weather assessment"""
    return {
        'average_difficulty': 0.5,
        'overall_rating': 'UNKNOWN',
        'global_recommendations': ['Weather data unavailable - use historical performance'],
        'locations_analyzed': 0
    }
