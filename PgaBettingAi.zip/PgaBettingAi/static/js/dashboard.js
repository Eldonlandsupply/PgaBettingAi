/**
 * PGA Betting AI Dashboard JavaScript
 * Handles dashboard functionality, charts, and real-time updates
 */

// Global variables
let performanceChart = null;
let betDistributionChart = null;
let updateInterval = null;

// Dashboard initialization
function initializeDashboard() {
    console.log('Initializing PGA Betting AI Dashboard...');
    
    // Initialize charts
    initializeCharts();
    
    // Load initial data
    loadDashboardData();
    
    // Set up auto-refresh (every 5 minutes)
    setupAutoRefresh();
    
    // Setup event listeners
    setupEventListeners();
}

/**
 * Initialize Chart.js charts
 */
function initializeCharts() {
    try {
        // Performance trend chart
        const performanceCtx = document.getElementById('performanceChart');
        if (performanceCtx) {
            performanceChart = new Chart(performanceCtx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Profit/Loss',
                        data: [],
                        borderColor: 'rgb(13, 110, 253)',
                        backgroundColor: 'rgba(13, 110, 253, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(255, 255, 255, 0.1)'
                            },
                            ticks: {
                                callback: function(value) {
                                    return '$' + value.toFixed(2);
                                }
                            }
                        },
                        x: {
                            grid: {
                                color: 'rgba(255, 255, 255, 0.1)'
                            }
                        }
                    },
                    interaction: {
                        intersect: false,
                        mode: 'index'
                    }
                }
            });
        }
        
        // Bet distribution pie chart
        const distributionCtx = document.getElementById('betDistributionChart');
        if (distributionCtx) {
            betDistributionChart = new Chart(distributionCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Win Bets', 'Top 5', 'Top 10', 'Make Cut'],
                    datasets: [{
                        data: [0, 0, 0, 0],
                        backgroundColor: [
                            'rgb(25, 135, 84)',   // Success
                            'rgb(13, 202, 240)',  // Info
                            'rgb(255, 193, 7)',   // Warning
                            'rgb(108, 117, 125)'  // Secondary
                        ],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 20,
                                usePointStyle: true
                            }
                        }
                    }
                }
            });
        }
        
        console.log('Charts initialized successfully');
    } catch (error) {
        console.error('Error initializing charts:', error);
    }
}

/**
 * Load all dashboard data
 */
async function loadDashboardData() {
    try {
        console.log('Loading dashboard data...');
        
        // Load user profile data
        await loadUserProfile();
        
        // Load performance data for charts
        await loadPerformanceData();
        
        // Load recent activity
        await loadRecentActivity();
        
        console.log('Dashboard data loaded successfully');
    } catch (error) {
        console.error('Error loading dashboard data:', error);
        showNotification('Error loading dashboard data. Please refresh the page.', 'error');
    }
}

/**
 * Load user profile and statistics
 */
async function loadUserProfile() {
    try {
        const response = await fetch('/api/users/profile');
        const data = await response.json();
        
        if (data.success && data.statistics) {
            updateMetricCards(data.statistics);
        } else {
            console.warn('Failed to load user profile:', data.error);
        }
    } catch (error) {
        console.error('Error loading user profile:', error);
    }
}

/**
 * Update metric cards with user statistics
 */
function updateMetricCards(statistics) {
    const betting = statistics.betting || {};
    
    // Update metric values
    updateMetricCard('totalProfit', betting.profit_loss || 0, true);
    updateMetricCard('winRate', betting.win_rate || 0, false, '%');
    updateMetricCard('totalStaked', betting.total_staked || 0, true);
    updateMetricCard('totalBets', betting.total_bets || 0, false);
    
    // Update profit/loss card color based on performance
    const profitCard = document.querySelector('#totalProfit').closest('.card');
    const profitValue = betting.profit_loss || 0;
    
    if (profitValue > 0) {
        profitCard.classList.add('border-success');
        profitCard.classList.remove('border-danger');
    } else if (profitValue < 0) {
        profitCard.classList.add('border-danger');
        profitCard.classList.remove('border-success');
    }
}

/**
 * Update individual metric card
 */
function updateMetricCard(elementId, value, isCurrency = false, suffix = '') {
    const element = document.getElementById(elementId);
    if (element) {
        let displayValue;
        
        if (isCurrency) {
            displayValue = '$' + Math.abs(value).toFixed(2);
            if (value < 0) displayValue = '-' + displayValue;
        } else {
            displayValue = value.toLocaleString() + suffix;
        }
        
        // Animate the value change
        animateValue(element, element.textContent, displayValue, 1000);
    }
}

/**
 * Animate value changes in metric cards
 */
function animateValue(element, start, end, duration) {
    // Simple animation for numeric values
    const startNum = parseFloat(start.replace(/[^0-9.-]/g, '')) || 0;
    const endNum = parseFloat(end.replace(/[^0-9.-]/g, '')) || 0;
    
    if (startNum === endNum) {
        element.textContent = end;
        return;
    }
    
    const range = endNum - startNum;
    const stepTime = Math.abs(Math.floor(duration / range));
    const startTime = new Date().getTime();
    
    const timer = setInterval(() => {
        const now = new Date().getTime();
        const remaining = Math.max((startTime + duration) - now, 0);
        const value = endNum - (remaining / duration) * range;
        
        if (end.includes('$')) {
            element.textContent = '$' + Math.abs(value).toFixed(2);
            if (value < 0) element.textContent = '-' + element.textContent;
        } else if (end.includes('%')) {
            element.textContent = Math.round(value) + '%';
        } else {
            element.textContent = Math.round(value).toLocaleString();
        }
        
        if (remaining === 0) {
            clearInterval(timer);
            element.textContent = end;
        }
    }, 16); // ~60fps
}

/**
 * Load performance data for charts
 */
async function loadPerformanceData() {
    try {
        // Generate mock performance data for demonstration
        // In production, this would come from actual betting history
        const performanceData = generateMockPerformanceData();
        
        if (performanceChart) {
            performanceChart.data.labels = performanceData.labels;
            performanceChart.data.datasets[0].data = performanceData.values;
            performanceChart.update('active');
        }
        
        // Update bet distribution chart
        const distributionData = generateMockDistributionData();
        if (betDistributionChart) {
            betDistributionChart.data.datasets[0].data = distributionData;
            betDistributionChart.update('active');
        }
        
    } catch (error) {
        console.error('Error loading performance data:', error);
    }
}

/**
 * Generate mock performance data
 * In production, this would fetch real betting history
 */
function generateMockPerformanceData() {
    const labels = [];
    const values = [];
    const today = new Date();
    
    // Generate last 30 days of data
    for (let i = 29; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);
        labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
        
        // Mock cumulative profit/loss with some volatility
        const baseValue = i * 2 - 30; // Slight upward trend
        const volatility = (Math.random() - 0.5) * 20; // Random fluctuation
        values.push(baseValue + volatility);
    }
    
    return { labels, values };
}

/**
 * Generate mock bet distribution data
 */
function generateMockDistributionData() {
    // Mock data - in production this would come from actual bet history
    return [30, 25, 20, 25]; // Win, Top5, Top10, MakeCut percentages
}

/**
 * Load recent activity data
 */
async function loadRecentActivity() {
    try {
        const response = await fetch('/api/users/profile');
        const data = await response.json();
        
        if (data.success && data.recent_activity) {
            displayRecentActivity(data.recent_activity);
        }
    } catch (error) {
        console.error('Error loading recent activity:', error);
    }
}

/**
 * Display recent activity in the dashboard
 */
function displayRecentActivity(recentActivity) {
    const activityElement = document.getElementById('recentActivity');
    if (!activityElement) return;
    
    const recentBets = recentActivity.recent_bets || [];
    
    if (recentBets.length === 0) {
        activityElement.innerHTML = `
            <div class="text-center py-4">
                <i class="fas fa-history text-muted mb-2"></i>
                <p class="text-muted">No recent activity</p>
            </div>
        `;
        return;
    }
    
    let activityHTML = '';
    recentBets.slice(0, 5).forEach(bet => {
        const statusClass = getStatusClass(bet.status);
        const statusIcon = getStatusIcon(bet.status);
        
        activityHTML += `
            <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                <div>
                    <div class="fw-bold">${bet.player_name}</div>
                    <small class="text-muted">${bet.bet_type} @ ${bet.odds}</small>
                </div>
                <div class="text-end">
                    <div class="fw-bold">$${bet.stake}</div>
                    <small class="${statusClass}">
                        <i class="${statusIcon} me-1"></i>
                        ${bet.status.charAt(0).toUpperCase() + bet.status.slice(1)}
                    </small>
                </div>
            </div>
        `;
    });
    
    activityElement.innerHTML = activityHTML;
}

/**
 * Get CSS class for bet status
 */
function getStatusClass(status) {
    switch (status) {
        case 'won': return 'text-success';
        case 'lost': return 'text-danger';
        case 'pending': return 'text-warning';
        default: return 'text-muted';
    }
}

/**
 * Get icon for bet status
 */
function getStatusIcon(status) {
    switch (status) {
        case 'won': return 'fas fa-check-circle';
        case 'lost': return 'fas fa-times-circle';
        case 'pending': return 'fas fa-clock';
        default: return 'fas fa-question-circle';
    }
}

/**
 * Setup auto-refresh functionality
 */
function setupAutoRefresh() {
    // Refresh dashboard data every 5 minutes
    updateInterval = setInterval(() => {
        console.log('Auto-refreshing dashboard data...');
        loadDashboardData();
    }, 5 * 60 * 1000); // 5 minutes
}

/**
 * Setup event listeners
 */
function setupEventListeners() {
    // Refresh button
    const refreshButton = document.querySelector('[onclick="refreshDashboard()"]');
    if (refreshButton) {
        refreshButton.removeAttribute('onclick');
        refreshButton.addEventListener('click', handleRefreshClick);
    }
    
    // Metric card click handlers for detailed views
    setupMetricCardListeners();
    
    // Window visibility change handler to pause/resume updates
    document.addEventListener('visibilitychange', handleVisibilityChange);
}

/**
 * Handle refresh button click
 */
async function handleRefreshClick(event) {
    const button = event.target;
    const originalHTML = button.innerHTML;
    
    button.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Refreshing...';
    button.disabled = true;
    
    try {
        await loadDashboardData();
        showNotification('Dashboard refreshed successfully!', 'success');
    } catch (error) {
        console.error('Error refreshing dashboard:', error);
        showNotification('Failed to refresh dashboard.', 'error');
    } finally {
        button.innerHTML = originalHTML;
        button.disabled = false;
    }
}

/**
 * Setup metric card click listeners
 */
function setupMetricCardListeners() {
    const metricCards = document.querySelectorAll('.metric-card');
    metricCards.forEach(card => {
        card.addEventListener('click', function() {
            // Add click animation
            this.style.transform = 'scale(0.98)';
            setTimeout(() => {
                this.style.transform = 'translateY(-2px)';
            }, 100);
        });
    });
}

/**
 * Handle page visibility changes
 */
function handleVisibilityChange() {
    if (document.hidden) {
        // Page is hidden, pause updates
        if (updateInterval) {
            clearInterval(updateInterval);
            updateInterval = null;
        }
    } else {
        // Page is visible, resume updates
        if (!updateInterval) {
            setupAutoRefresh();
        }
        // Refresh data when page becomes visible
        loadDashboardData();
    }
}

/**
 * Show notification toast
 */
function showNotification(message, type = 'info') {
    const toast = document.createElement('div');
    const bgClass = type === 'success' ? 'bg-success' : 
                   type === 'error' ? 'bg-danger' : 
                   type === 'warning' ? 'bg-warning' : 'bg-info';
    
    toast.className = `toast align-items-center text-white ${bgClass} border-0 position-fixed top-0 end-0 m-3`;
    toast.setAttribute('role', 'alert');
    toast.style.zIndex = '9999';
    
    const icon = type === 'success' ? 'fas fa-check-circle' :
                type === 'error' ? 'fas fa-exclamation-triangle' :
                type === 'warning' ? 'fas fa-exclamation-triangle' :
                'fas fa-info-circle';
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                <i class="${icon} me-2"></i>${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    
    document.body.appendChild(toast);
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
    
    // Remove from DOM after hiding
    toast.addEventListener('hidden.bs.toast', () => toast.remove());
}

/**
 * Update chart themes based on current theme
 */
function updateChartThemes() {
    const isDark = document.documentElement.getAttribute('data-bs-theme') === 'dark';
    const textColor = isDark ? '#adb5bd' : '#6c757d';
    const gridColor = isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)';
    
    if (performanceChart) {
        performanceChart.options.scales.x.ticks.color = textColor;
        performanceChart.options.scales.y.ticks.color = textColor;
        performanceChart.options.scales.x.grid.color = gridColor;
        performanceChart.options.scales.y.grid.color = gridColor;
        performanceChart.update('none');
    }
    
    if (betDistributionChart) {
        betDistributionChart.options.plugins.legend.labels.color = textColor;
        betDistributionChart.update('none');
    }
}

/**
 * Cleanup function
 */
function cleanup() {
    if (updateInterval) {
        clearInterval(updateInterval);
        updateInterval = null;
    }
    
    if (performanceChart) {
        performanceChart.destroy();
        performanceChart = null;
    }
    
    if (betDistributionChart) {
        betDistributionChart.destroy();
        betDistributionChart = null;
    }
}

// Theme change listener
if (window.matchMedia) {
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', updateChartThemes);
}

// Page unload cleanup
window.addEventListener('beforeunload', cleanup);

// Initialize when DOM is loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeDashboard);
} else {
    initializeDashboard();
}

// Export functions for global access
window.dashboardJS = {
    refresh: handleRefreshClick,
    cleanup: cleanup,
    showNotification: showNotification
};
